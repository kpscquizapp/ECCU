import React from 'react';
import { motion } from 'framer-motion';
import { Shield, AlertTriangle, CheckCircle, FileText, Users, ArrowUpRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const ComplianceMonitoring: React.FC = () => {
  // Mock data for compliance metrics
  const complianceMetrics = {
    amlCompliance: 94,
    kycCompliance: 88,
    regulatoryReports: 100,
    pendingReviews: 12,
  };

  const recentViolations = [
    {
      id: 1,
      type: 'KYC',
      description: 'Incomplete customer verification documentation',
      severity: 'high',
      date: '2025-06-02',
      status: 'pending',
    },
    {
      id: 2,
      type: 'AML',
      description: 'Suspicious transaction pattern detected',
      severity: 'medium',
      date: '2025-06-01',
      status: 'investigating',
    },
    {
      id: 3,
      type: 'Regulatory',
      description: 'Late submission of monthly report',
      severity: 'low',
      date: '2025-05-30',
      status: 'resolved',
    },
  ];

  const upcomingDeadlines = [
    {
      id: 1,
      title: 'Quarterly AML Report',
      dueDate: '2025-06-30',
      status: 'pending',
      type: 'report',
    },
    {
      id: 2,
      title: 'Annual KYC Review',
      dueDate: '2025-07-15',
      status: 'in_progress',
      type: 'review',
    },
    {
      id: 3,
      title: 'Risk Assessment Update',
      dueDate: '2025-06-10',
      status: 'pending',
      type: 'assessment',
    },
  ];

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case 'high':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-secondary-100 text-secondary-800 dark:bg-secondary-900/30 dark:text-secondary-300">
            <AlertTriangle size={12} className="mr-1" />
            High
          </span>
        );
      case 'medium':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-accent-100 text-accent-800 dark:bg-accent-900/30 dark:text-accent-300">
            Medium
          </span>
        );
      case 'low':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300">
            Low
          </span>
        );
      default:
        return null;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-accent-100 text-accent-800 dark:bg-accent-900/30 dark:text-accent-300">
            Pending
          </span>
        );
      case 'investigating':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800 dark:bg-primary-900/30 dark:text-primary-300">
            Investigating
          </span>
        );
      case 'resolved':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300">
            <CheckCircle size={12} className="mr-1" />
            Resolved
          </span>
        );
      case 'in_progress':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300">
            In Progress
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Compliance Monitoring</h1>
          <p className="text-gray-600 dark:text-gray-300">
            Monitor and manage regulatory compliance
          </p>
        </div>
        <div className="flex space-x-3">
          <button className="btn btn-tertiary flex items-center gap-2">
            <FileText size={16} />
            <span>Generate Report</span>
          </button>
          <button className="btn btn-primary flex items-center gap-2">
            <Shield size={16} />
            <span>Review Policies</span>
          </button>
        </div>
      </div>

      {/* Compliance Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">AML Compliance</h3>
            <div className="p-2 rounded-full bg-green-100 dark:bg-green-900/20">
              <Shield size={20} className="text-green-600 dark:text-green-400" />
            </div>
          </div>
          <div className="flex items-end justify-between">
            <div className="space-y-1">
              <p className="text-3xl font-bold text-green-600 dark:text-green-400">
                {complianceMetrics.amlCompliance}%
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Last updated today
              </p>
            </div>
            <span className="text-sm text-green-600 dark:text-green-400">+2.5%</span>
          </div>
        </div>

        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">KYC Compliance</h3>
            <div className="p-2 rounded-full bg-accent-100 dark:bg-accent-900/20">
              <Users size={20} className="text-accent-600 dark:text-accent-400" />
            </div>
          </div>
          <div className="flex items-end justify-between">
            <div className="space-y-1">
              <p className="text-3xl font-bold text-accent-600 dark:text-accent-400">
                {complianceMetrics.kycCompliance}%
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Last updated today
              </p>
            </div>
            <span className="text-sm text-accent-600 dark:text-accent-400">-1.2%</span>
          </div>
        </div>

        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Regulatory Reports</h3>
            <div className="p-2 rounded-full bg-primary-100 dark:bg-primary-900/20">
              <FileText size={20} className="text-primary-600 dark:text-primary-400" />
            </div>
          </div>
          <div className="flex items-end justify-between">
            <div className="space-y-1">
              <p className="text-3xl font-bold text-primary-600 dark:text-primary-400">
                {complianceMetrics.regulatoryReports}%
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                All reports submitted
              </p>
            </div>
            <span className="text-sm text-primary-600 dark:text-primary-400">On Track</span>
          </div>
        </div>

        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Pending Reviews</h3>
            <div className="p-2 rounded-full bg-secondary-100 dark:bg-secondary-900/20">
              <AlertTriangle size={20} className="text-secondary-600 dark:text-secondary-400" />
            </div>
          </div>
          <div className="flex items-end justify-between">
            <div className="space-y-1">
              <p className="text-3xl font-bold text-secondary-600 dark:text-secondary-400">
                {complianceMetrics.pendingReviews}
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Require attention
              </p>
            </div>
            <span className="text-sm text-secondary-600 dark:text-secondary-400">Urgent</span>
          </div>
        </div>
      </div>

      {/* Recent Violations and Upcoming Deadlines */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold">Recent Violations</h2>
            <Link
              to="#"
              className="text-sm text-primary-600 dark:text-primary-400 hover:underline flex items-center gap-1"
            >
              View All
              <ArrowUpRight size={14} />
            </Link>
          </div>

          <div className="space-y-4">
            {recentViolations.map((violation) => (
              <div
                key={violation.id}
                className="p-4 bg-gray-50 dark:bg-tertiary-800 rounded-lg"
              >
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300 mb-2">
                      {violation.type}
                    </span>
                    <p className="text-sm">{violation.description}</p>
                  </div>
                  {getSeverityBadge(violation.severity)}
                </div>
                <div className="flex items-center justify-between mt-3">
                  <span className="text-xs text-gray-500 dark:text-gray-400">
                    {violation.date}
                  </span>
                  {getStatusBadge(violation.status)}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold">Upcoming Deadlines</h2>
            <Link
              to="#"
              className="text-sm text-primary-600 dark:text-primary-400 hover:underline flex items-center gap-1"
            >
              View Calendar
              <ArrowUpRight size={14} />
            </Link>
          </div>

          <div className="space-y-4">
            {upcomingDeadlines.map((deadline) => (
              <div
                key={deadline.id}
                className="p-4 bg-gray-50 dark:bg-tertiary-800 rounded-lg"
              >
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h4 className="font-medium">{deadline.title}</h4>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Due: {deadline.dueDate}
                    </p>
                  </div>
                  {getStatusBadge(deadline.status)}
                </div>
                <div className="mt-3">
                  <button className="text-sm text-primary-600 dark:text-primary-400 hover:underline">
                    View Details
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Compliance Resources */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="card bg-gradient-to-br from-primary-500 to-primary-700 text-white">
          <div className="flex items-center space-x-4 mb-4">
            <div className="bg-white/20 p-3 rounded-lg">
              <Shield size={20} />
            </div>
            <h3 className="text-lg font-semibold">AML Guidelines</h3>
          </div>
          <p className="text-primary-100 mb-4">
            Access the latest anti-money laundering guidelines and best practices.
          </p>
          <button className="px-4 py-2 bg-white text-primary-700 rounded-md font-medium hover:bg-primary-50 transition-colors">
            View Guidelines
          </button>
        </div>

        <div className="card bg-gradient-to-br from-accent-500 to-accent-700 text-white">
          <div className="flex items-center space-x-4 mb-4">
            <div className="bg-white/20 p-3 rounded-lg">
              <Users size={20} />
            </div>
            <h3 className="text-lg font-semibold">KYC Procedures</h3>
          </div>
          <p className="text-accent-100 mb-4">
            Review customer due diligence procedures and verification requirements.
          </p>
          <button className="px-4 py-2 bg-white text-accent-700 rounded-md font-medium hover:bg-accent-50 transition-colors">
            View Procedures
          </button>
        </div>

        <div className="card bg-gradient-to-br from-secondary-500 to-secondary-700 text-white">
          <div className="flex items-center space-x-4 mb-4">
            <div className="bg-white/20 p-3 rounded-lg">
              <FileText size={20} />
            </div>
            <h3 className="text-lg font-semibold">Report Templates</h3>
          </div>
          <p className="text-secondary-100 mb-4">
            Access standardized templates for regulatory reporting and documentation.
          </p>
          <button className="px-4 py-2 bg-white text-secondary-700 rounded-md font-medium hover:bg-secondary-50 transition-colors">
            View Templates
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default ComplianceMonitoring;