import React from 'react';
import { motion } from 'framer-motion';
import { Coins, ArrowUpRight, FileText, Users, TrendingUp, AlertTriangle, Network } from 'lucide-react';
import { Link } from 'react-router-dom';

const MoneyLaundering: React.FC = () => {
  const launderingCases = [
    {
      id: 'ML001',
      title: 'Cross-Border Shell Companies',
      type: 'Corporate Structure',
      status: 'active',
      riskLevel: 'high',
      lastUpdated: '2025-06-02',
      value: '12.5M USD',
      description: 'Investigation into network of shell companies used for cross-border money laundering.',
      entities: 8,
    },
    {
      id: 'ML002',
      title: 'Crypto Exchange Scheme',
      type: 'Digital Assets',
      status: 'investigating',
      riskLevel: 'high',
      lastUpdated: '2025-06-01',
      value: '8.3M USD',
      description: 'Money laundering operation using multiple cryptocurrency exchanges and mixers.',
      entities: 5,
    },
    {
      id: 'ML003',
      title: 'Real Estate Investment Chain',
      type: 'Property',
      status: 'active',
      riskLevel: 'high',
      lastUpdated: '2025-05-30',
      value: '15.7M USD',
      description: 'Complex scheme involving multiple property transactions to layer illicit funds.',
      entities: 12,
    },
    {
      id: 'ML004',
      title: 'Trade-Based Laundering',
      type: 'International Trade',
      status: 'pending',
      riskLevel: 'medium',
      lastUpdated: '2025-05-28',
      value: '6.2M USD',
      description: 'Over/under-invoicing scheme using international trade transactions.',
      entities: 6,
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Coins className="text-primary-500" />
            Money Laundering
          </h1>
          <p className="text-gray-600 dark:text-gray-300">
            Track and investigate money laundering operations
          </p>
        </div>
        <div className="flex space-x-3">
          <button className="btn btn-tertiary flex items-center gap-2">
            <FileText size={16} />
            <span>Generate Report</span>
          </button>
          <Link to="/cases/new" className="btn btn-primary flex items-center gap-2">
            <span>New Case</span>
            <ArrowUpRight size={16} />
          </Link>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="card">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-lg font-semibold">Active Cases</h3>
            <FileText className="text-primary-500" size={20} />
          </div>
          <p className="text-3xl font-bold">15</p>
          <p className="text-sm text-gray-500 dark:text-gray-400">+3 this month</p>
        </div>

        <div className="card">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-lg font-semibold">Entities</h3>
            <Users className="text-secondary-500" size={20} />
          </div>
          <p className="text-3xl font-bold">31</p>
          <p className="text-sm text-gray-500 dark:text-gray-400">Under investigation</p>
        </div>

        <div className="card">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-lg font-semibold">Total Value</h3>
            <TrendingUp className="text-accent-500" size={20} />
          </div>
          <p className="text-3xl font-bold">$42.7M</p>
          <p className="text-sm text-gray-500 dark:text-gray-400">Suspected laundering</p>
        </div>

        <div className="card">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-lg font-semibold">Networks</h3>
            <Network className="text-green-500" size={20} />
          </div>
          <p className="text-3xl font-bold">8</p>
          <p className="text-sm text-gray-500 dark:text-gray-400">Criminal networks</p>
        </div>
      </div>

      {/* Active Cases */}
      <div className="card">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold">Active Cases</h2>
          <Link
            to="/cases"
            className="text-sm text-primary-600 dark:text-primary-400 hover:underline flex items-center gap-1"
          >
            View All Cases
            <ArrowUpRight size={14} />
          </Link>
        </div>

        <div className="space-y-4">
          {launderingCases.map((case_) => (
            <div
              key={case_.id}
              className="p-4 bg-gray-50 dark:bg-tertiary-800 rounded-lg hover:bg-gray-100 dark:hover:bg-tertiary-700 transition-colors"
            >
              <div className="flex items-start justify-between mb-2">
                <div>
                  <Link
                    to={`/cases/${case_.id}`}
                    className="text-lg font-medium hover:text-primary-600 dark:hover:text-primary-400"
                  >
                    {case_.title}
                  </Link>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-sm text-gray-500 dark:text-gray-400">
                      {case_.type}
                    </span>
                    <span className="text-sm text-gray-500 dark:text-gray-400">
                      • {case_.entities} entities
                    </span>
                    <span className="text-sm text-gray-500 dark:text-gray-400">
                      • {case_.value}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span
                    className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      case_.riskLevel === 'high'
                        ? 'bg-secondary-100 text-secondary-800 dark:bg-secondary-900/30 dark:text-secondary-300'
                        : 'bg-accent-100 text-accent-800 dark:bg-accent-900/30 dark:text-accent-300'
                    }`}
                  >
                    {case_.riskLevel === 'high' && <AlertTriangle size={12} className="mr-1" />}
                    {case_.riskLevel.charAt(0).toUpperCase() + case_.riskLevel.slice(1)} Risk
                  </span>
                </div>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-300 mb-3">
                {case_.description}
              </p>
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-500 dark:text-gray-400">
                  Last updated: {case_.lastUpdated}
                </span>
                <Link
                  to={`/cases/${case_.id}`}
                  className="text-primary-600 dark:text-primary-400 hover:underline flex items-center gap-1"
                >
                  View Details
                  <ArrowUpRight size={14} />
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Resources */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="card bg-gradient-to-br from-primary-500 to-primary-700 text-white">
          <div className="flex items-center space-x-4 mb-4">
            <div className="bg-white/20 p-3 rounded-lg">
              <Network size={20} />
            </div>
            <h3 className="text-lg font-semibold">Network Analysis</h3>
          </div>
          <p className="text-primary-100 mb-4">
            Advanced tools for mapping and analyzing money laundering networks.
          </p>
          <button className="px-4 py-2 bg-white text-primary-700 rounded-md font-medium hover:bg-primary-50 transition-colors">
            Access Tools
          </button>
        </div>

        <div className="card bg-gradient-to-br from-secondary-500 to-secondary-700 text-white">
          <div className="flex items-center space-x-4 mb-4">
            <div className="bg-white/20 p-3 rounded-lg">
              <AlertTriangle size={20} />
            </div>
            <h3 className="text-lg font-semibold">Risk Indicators</h3>
          </div>
          <p className="text-secondary-100 mb-4">
            Guide to identifying and assessing money laundering risk factors.
          </p>
          <button className="px-4 py-2 bg-white text-secondary-700 rounded-md font-medium hover:bg-secondary-50 transition-colors">
            View Guide
          </button>
        </div>

        <div className="card bg-gradient-to-br from-accent-500 to-accent-700 text-white">
          <div className="flex items-center space-x-4 mb-4">
            <div className="bg-white/20 p-3 rounded-lg">
              <FileText size={20} />
            </div>
            <h3 className="text-lg font-semibold">Compliance Resources</h3>
          </div>
          <p className="text-accent-100 mb-4">
            Access AML compliance guidelines and reporting templates.
          </p>
          <button className="px-4 py-2 bg-white text-accent-700 rounded-md font-medium hover:bg-accent-50 transition-colors">
            View Resources
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default MoneyLaundering;