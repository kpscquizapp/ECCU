import React from 'react';
import { motion } from 'framer-motion';
import { ArrowUpRight, FileText, AlertTriangle, Clock, TrendingUp, Users, Link as LinkIcon, Shield, Bitcoin, Network, FileCheck } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { Link as RouterLink } from 'react-router-dom';

// Components
import StatCard from '../components/dashboard/StatCard';
import CasesByTypeChart from '../components/dashboard/CasesByTypeChart';
import RecentActivityList from '../components/dashboard/RecentActivityList';
import PriorityAlertsList from '../components/dashboard/PriorityAlertsList';
import RiskScoreWidget from '../components/dashboard/RiskScoreWidget';

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  
  const stats = [
    {
      title: 'Active Cases',
      value: '24',
      change: '+6%',
      icon: <FileText className="text-primary-500" />,
      color: 'primary',
    },
    {
      title: 'High Risk Alerts',
      value: '7',
      change: '-12%',
      icon: <AlertTriangle className="text-secondary-500" />,
      color: 'secondary',
    },
    {
      title: 'Avg. Resolution Time',
      value: '8.2 days',
      change: '-14%',
      icon: <Clock className="text-accent-500" />,
      color: 'accent',
    },
    {
      title: 'Detection Rate',
      value: '94%',
      change: '+3%',
      icon: <TrendingUp className="text-success-500" />,
      color: 'success',
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <p className="text-gray-600 dark:text-gray-300">
            Welcome back, {user?.name}
          </p>
        </div>
        <div className="flex space-x-3">
          <button className="btn btn-tertiary">
            Export Reports
          </button>
          <RouterLink to="/cases" className="btn btn-primary flex items-center gap-2">
            <span>View Cases</span>
            <ArrowUpRight size={16} />
          </RouterLink>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <StatCard
            key={index}
            title={stat.title}
            value={stat.value}
            change={stat.change}
            icon={stat.icon}
            color={stat.color}
          />
        ))}
      </div>

      {/* Main content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Cases by Type */}
        <div className="lg:col-span-2">
          <div className="card h-full">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold">Case Distribution</h2>
              <button className="text-sm text-primary-600 dark:text-primary-400 hover:underline">View All</button>
            </div>
            <div className="h-80">
              <CasesByTypeChart />
            </div>
          </div>
        </div>

        {/* Risk Score */}
        <div>
          <div className="card h-full">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold">Risk Analysis</h2>
              <button className="text-sm text-primary-600 dark:text-primary-400 hover:underline">Details</button>
            </div>
            <RiskScoreWidget />
          </div>
        </div>
      </div>

      {/* Additional content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Activity */}
        <div className="lg:col-span-2">
          <div className="card h-full">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold">Recent Activity</h2>
              <button className="text-sm text-primary-600 dark:text-primary-400 hover:underline">View All</button>
            </div>
            <RecentActivityList />
          </div>
        </div>

        {/* Priority Alerts */}
        <div>
          <div className="card h-full">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold">Priority Alerts</h2>
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-secondary-100 text-secondary-800 dark:bg-secondary-900/30 dark:text-secondary-300">
                2 New
              </span>
            </div>
            <PriorityAlertsList />
          </div>
        </div>
      </div>

      {/* Feature Blocks with enhanced design */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <motion.div 
          whileHover={{ scale: 1.02 }}
          transition={{ type: "spring", stiffness: 300 }}
          className="card bg-gradient-to-br from-primary-500 to-primary-700 text-white overflow-hidden relative group"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 -translate-x-16 group-hover:scale-150 transition-transform duration-500"></div>
          <div className="relative z-10">
            <div className="flex items-center space-x-4 mb-4">
              <div className="bg-white/20 p-3 rounded-lg">
                <Bitcoin size={24} />
              </div>
              <h3 className="text-lg font-semibold">Blockchain Analysis</h3>
            </div>
            <p className="text-primary-100 mb-6 min-h-[60px]">
              Advanced blockchain forensics tools to trace cryptocurrency transactions and identify illicit activities in real-time.
            </p>
            <RouterLink 
              to="/analysis/blockchain"
              className="inline-flex items-center px-4 py-2 bg-white text-primary-700 rounded-md font-medium hover:bg-primary-50 transition-colors group"
            >
              <span>Explore</span>
              <ArrowUpRight size={16} className="ml-2 transition-transform group-hover:translate-x-1 group-hover:-translate-y-1" />
            </RouterLink>
          </div>
        </motion.div>
        
        <motion.div 
          whileHover={{ scale: 1.02 }}
          transition={{ type: "spring", stiffness: 300 }}
          className="card bg-gradient-to-br from-tertiary-700 to-tertiary-900 text-white overflow-hidden relative group"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 -translate-x-16 group-hover:scale-150 transition-transform duration-500"></div>
          <div className="relative z-10">
            <div className="flex items-center space-x-4 mb-4">
              <div className="bg-white/20 p-3 rounded-lg">
                <Network size={24} />
              </div>
              <h3 className="text-lg font-semibold">Network Analysis</h3>
            </div>
            <p className="text-gray-300 mb-6 min-h-[60px]">
              Interactive visualization tools to map and analyze complex financial networks and entity relationships.
            </p>
            <RouterLink 
              to="/analysis/network"
              className="inline-flex items-center px-4 py-2 bg-white text-tertiary-800 rounded-md font-medium hover:bg-gray-100 transition-colors group"
            >
              <span>Explore</span>
              <ArrowUpRight size={16} className="ml-2 transition-transform group-hover:translate-x-1 group-hover:-translate-y-1" />
            </RouterLink>
          </div>
        </motion.div>
        
        <motion.div 
          whileHover={{ scale: 1.02 }}
          transition={{ type: "spring", stiffness: 300 }}
          className="card bg-gradient-to-br from-secondary-500 to-secondary-700 text-white overflow-hidden relative group"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 -translate-x-16 group-hover:scale-150 transition-transform duration-500"></div>
          <div className="relative z-10">
            <div className="flex items-center space-x-4 mb-4">
              <div className="bg-white/20 p-3 rounded-lg">
                <FileCheck size={24} />
              </div>
              <h3 className="text-lg font-semibold">AML Compliance</h3>
            </div>
            <p className="text-secondary-100 mb-6 min-h-[60px]">
              Real-time monitoring and reporting tools to ensure AML/KYC compliance and detect regulatory violations.
            </p>
            <RouterLink 
              to="/compliance/aml"
              className="inline-flex items-center px-4 py-2 bg-white text-secondary-700 rounded-md font-medium hover:bg-secondary-50 transition-colors group"
            >
              <span>Explore</span>
              <ArrowUpRight size={16} className="ml-2 transition-transform group-hover:translate-x-1 group-hover:-translate-y-1" />
            </RouterLink>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default Dashboard;