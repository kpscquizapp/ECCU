import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './contexts/AuthContext';
import { AnimatePresence } from 'framer-motion';

// Layouts
import AuthLayout from './layouts/AuthLayout';
import DashboardLayout from './layouts/DashboardLayout';

// Pages
import Dashboard from './pages/Dashboard';
import Login from './pages/Login';
import CaseManagement from './pages/CaseManagement';
import CaseDetails from './pages/CaseDetails';
import DataAnalysis from './pages/DataAnalysis';
import ComplianceMonitoring from './pages/ComplianceMonitoring';
import Settings from './pages/Settings';
import NotFound from './pages/NotFound';

// Crime Type Pages
import CorporateFraud from './pages/crimes/CorporateFraud';
import FinancialScams from './pages/crimes/FinancialScams';
import MoneyLaundering from './pages/crimes/MoneyLaundering';
import Embezzlement from './pages/crimes/Embezzlement';

// Protected route component
const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { user } = useAuth();
  
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  
  return <>{children}</>;
};

function App() {
  return (
    <AnimatePresence mode="wait">
      <Routes>
        {/* Auth routes */}
        <Route element={<AuthLayout />}>
          <Route path="/login" element={<Login />} />
        </Route>
        
        {/* Dashboard routes */}
        <Route 
          element={
            <ProtectedRoute>
              <DashboardLayout />
            </ProtectedRoute>
          }
        >
          <Route path="/" element={<Dashboard />} />
          <Route path="/cases" element={<CaseManagement />} />
          <Route path="/cases/:id" element={<CaseDetails />} />
          <Route path="/analysis" element={<DataAnalysis />} />
          <Route path="/compliance" element={<ComplianceMonitoring />} />
          <Route path="/settings" element={<Settings />} />
          
          {/* Crime Type Routes */}
          <Route path="/crimes/corporate-fraud" element={<CorporateFraud />} />
          <Route path="/crimes/financial-scams" element={<FinancialScams />} />
          <Route path="/crimes/money-laundering" element={<MoneyLaundering />} />
          <Route path="/crimes/embezzlement" element={<Embezzlement />} />
        </Route>
        
        {/* Fallback route */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </AnimatePresence>
  );
}

export default App;