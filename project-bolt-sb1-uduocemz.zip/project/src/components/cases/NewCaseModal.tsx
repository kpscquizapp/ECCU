import React, { useState } from 'react';
import { X, Upload, AlertTriangle } from 'lucide-react';
import { motion } from 'framer-motion';

interface NewCaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (caseData: any) => void;
}

const NewCaseModal: React.FC<NewCaseModalProps> = ({ isOpen, onClose, onSubmit }) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    type: 'fraud',
    priority: 'medium',
    assignedTo: '',
    relatedEntities: '',
    initialEvidence: null as File | null,
    suspectedAmount: '',
    jurisdiction: '',
    sourceOfInformation: '',
    witnesses: '',
    additionalNotes: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFormData({ ...formData, initialEvidence: e.target.files[0] });
    }
  };

  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4"
    >
      <motion.div
        initial={{ scale: 0.95 }}
        animate={{ scale: 1 }}
        exit={{ scale: 0.95 }}
        className="bg-white dark:bg-tertiary-700 rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto"
      >
        <div className="p-6 border-b border-gray-200 dark:border-tertiary-600 flex items-center justify-between">
          <h2 className="text-2xl font-bold">New Case</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
          >
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium mb-2">Case Title</label>
              <input
                type="text"
                className="input"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Case Type</label>
              <select
                className="input"
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                required
              >
                <option value="fraud">Fraud</option>
                <option value="money_laundering">Money Laundering</option>
                <option value="embezzlement">Embezzlement</option>
                <option value="corruption">Corruption</option>
                <option value="cybercrime">Cybercrime</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Priority</label>
              <select
                className="input"
                value={formData.priority}
                onChange={(e) => setFormData({ ...formData, priority: e.target.value })}
                required
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Assign To</label>
              <select
                className="input"
                value={formData.assignedTo}
                onChange={(e) => setFormData({ ...formData, assignedTo: e.target.value })}
                required
              >
                <option value="">Select Investigator</option>
                <option value="john_kamau">John Kamau</option>
                <option value="sarah_njeri">Sarah Njeri</option>
                <option value="daniel_omondi">Daniel Omondi</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Jurisdiction</label>
              <input
                type="text"
                className="input"
                value={formData.jurisdiction}
                onChange={(e) => setFormData({ ...formData, jurisdiction: e.target.value })}
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Suspected Amount (KES)</label>
              <input
                type="number"
                className="input"
                value={formData.suspectedAmount}
                onChange={(e) => setFormData({ ...formData, suspectedAmount: e.target.value })}
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Case Description</label>
            <textarea
              className="input h-32 resize-none"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              required
            ></textarea>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Related Entities</label>
            <textarea
              className="input h-24 resize-none"
              value={formData.relatedEntities}
              onChange={(e) => setFormData({ ...formData, relatedEntities: e.target.value })}
              placeholder="List any individuals, companies, or organizations involved..."
            ></textarea>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Source of Information</label>
            <input
              type="text"
              className="input"
              value={formData.sourceOfInformation}
              onChange={(e) => setFormData({ ...formData, sourceOfInformation: e.target.value })}
              placeholder="How was this case discovered?"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Witnesses</label>
            <textarea
              className="input h-24 resize-none"
              value={formData.witnesses}
              onChange={(e) => setFormData({ ...formData, witnesses: e.target.value })}
              placeholder="List any potential witnesses..."
            ></textarea>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Initial Evidence</label>
            <div className="border-2 border-dashed border-gray-300 dark:border-tertiary-600 rounded-lg p-6 text-center">
              <input
                type="file"
                id="evidence"
                className="hidden"
                onChange={handleFileChange}
                multiple
              />
              <label
                htmlFor="evidence"
                className="cursor-pointer flex flex-col items-center space-y-2"
              >
                <Upload className="text-gray-400" size={24} />
                <span className="text-sm text-gray-500 dark:text-gray-400">
                  Click to upload or drag and drop
                </span>
                <span className="text-xs text-gray-400">
                  PDF, DOC, JPG, PNG (max. 10MB each)
                </span>
              </label>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Additional Notes</label>
            <textarea
              className="input h-24 resize-none"
              value={formData.additionalNotes}
              onChange={(e) => setFormData({ ...formData, additionalNotes: e.target.value })}
              placeholder="Any additional information..."
            ></textarea>
          </div>

          <div className="bg-secondary-50 dark:bg-secondary-900/20 p-4 rounded-lg flex items-start gap-3">
            <AlertTriangle className="text-secondary-500 flex-shrink-0 mt-1" size={20} />
            <div>
              <h4 className="font-medium text-secondary-700 dark:text-secondary-300">
                Important Notice
              </h4>
              <p className="text-sm text-secondary-600 dark:text-secondary-400 mt-1">
                Ensure all information provided is accurate and complete. False reporting may lead to
                legal consequences. All case information is confidential and subject to ECCU
                regulations.
              </p>
            </div>
          </div>

          <div className="flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="btn btn-tertiary"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="btn btn-primary"
            >
              Create Case
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
};

export default NewCaseModal;