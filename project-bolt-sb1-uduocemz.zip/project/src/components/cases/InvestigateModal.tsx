import React, { useState } from 'react';
import { X, Search, AlertTriangle, FileText, Users, Building2, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';

interface InvestigateModalProps {
  isOpen: boolean;
  onClose: () => void;
  caseId: string;
  caseTitle: string;
}

const InvestigateModal: React.FC<InvestigateModalProps> = ({ isOpen, onClose, caseId, caseTitle }) => {
  const [activeTab, setActiveTab] = useState('overview');

  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4"
    >
      <motion.div
        initial={{ scale: 0.95 }}
        animate={{ scale: 1 }}
        exit={{ scale: 0.95 }}
        className="bg-white dark:bg-tertiary-700 rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto"
      >
        <div className="p-6 border-b border-gray-200 dark:border-tertiary-600 flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold">Investigate Case</h2>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
              Case #{caseId} - {caseTitle}
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
          >
            <X size={24} />
          </button>
        </div>

        <div className="border-b border-gray-200 dark:border-tertiary-600">
          <nav className="flex space-x-6 px-6">
            <button
              onClick={() => setActiveTab('overview')}
              className={`py-4 px-1 relative font-medium text-sm ${
                activeTab === 'overview'
                  ? 'text-primary-600 dark:text-primary-400 border-b-2 border-primary-500'
                  : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
              }`}
            >
              Overview
            </button>
            <button
              onClick={() => setActiveTab('entities')}
              className={`py-4 px-1 relative font-medium text-sm ${
                activeTab === 'entities'
                  ? 'text-primary-600 dark:text-primary-400 border-b-2 border-primary-500'
                  : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
              }`}
            >
              Related Entities
            </button>
            <button
              onClick={() => setActiveTab('transactions')}
              className={`py-4 px-1 relative font-medium text-sm ${
                activeTab === 'transactions'
                  ? 'text-primary-600 dark:text-primary-400 border-b-2 border-primary-500'
                  : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
              }`}
            >
              Transactions
            </button>
            <button
              onClick={() => setActiveTab('documents')}
              className={`py-4 px-1 relative font-medium text-sm ${
                activeTab === 'documents'
                  ? 'text-primary-600 dark:text-primary-400 border-b-2 border-primary-500'
                  : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
              }`}
            >
              Documents
            </button>
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 bg-primary-50 dark:bg-primary-900/20 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Search className="text-primary-500" size={20} />
                    <h3 className="font-medium">Investigation Status</h3>
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    Active investigation with 3 leads
                  </p>
                </div>

                <div className="p-4 bg-secondary-50 dark:bg-secondary-900/20 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertTriangle className="text-secondary-500" size={20} />
                    <h3 className="font-medium">Risk Level</h3>
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    High - Multiple red flags detected
                  </p>
                </div>

                <div className="p-4 bg-accent-50 dark:bg-accent-900/20 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Users className="text-accent-500" size={20} />
                    <h3 className="font-medium">Team Members</h3>
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    4 investigators assigned
                  </p>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="font-medium">Recent Activities</h3>
                <div className="space-y-3">
                  {[1, 2, 3].map((activity) => (
                    <div
                      key={activity}
                      className="p-3 bg-gray-50 dark:bg-tertiary-800 rounded-lg"
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium">Document Analysis Complete</span>
                        <span className="text-sm text-gray-500">2 hours ago</span>
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-300">
                        AI analysis of financial statements revealed potential discrepancies
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'entities' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h3 className="font-medium">Connected Entities</h3>
                <button className="btn btn-primary">Add Entity</button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[1, 2, 3, 4].map((entity) => (
                  <div
                    key={entity}
                    className="p-4 border border-gray-200 dark:border-tertiary-600 rounded-lg"
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-2">
                          <Building2 size={16} className="text-gray-500" />
                          <h4 className="font-medium">Global Finance Ltd</h4>
                        </div>
                        <p className="text-sm text-gray-500 mt-1">Financial Institution</p>
                      </div>
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-secondary-100 text-secondary-800">
                        High Risk
                      </span>
                    </div>
                    <div className="mt-4 pt-4 border-t border-gray-100 dark:border-tertiary-700">
                      <button className="text-primary-600 text-sm hover:underline">
                        View Details
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'transactions' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h3 className="font-medium">Suspicious Transactions</h3>
                <button className="btn btn-primary">Add Transaction</button>
              </div>

              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-tertiary-600">
                  <thead>
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Date
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Amount
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Type
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Status
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200 dark:divide-tertiary-600">
                    {[1, 2, 3, 4].map((transaction) => (
                      <tr key={transaction}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm">
                          2025-06-02
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm">
                          KES 2,500,000
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm">
                          Wire Transfer
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm">
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-secondary-100 text-secondary-800">
                            Suspicious
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm">
                          <button className="text-primary-600 hover:text-primary-800">
                            View Details
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'documents' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h3 className="font-medium">Case Documents</h3>
                <button className="btn btn-primary">Upload Document</button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[1, 2, 3, 4].map((doc) => (
                  <div
                    key={doc}
                    className="p-4 border border-gray-200 dark:border-tertiary-600 rounded-lg"
                  >
                    <div className="flex items-start gap-3">
                      <div className="p-2 bg-primary-50 dark:bg-primary-900/20 rounded">
                        <FileText className="text-primary-500" size={20} />
                      </div>
                      <div>
                        <h4 className="font-medium">Financial Statement Q3 2024</h4>
                        <p className="text-sm text-gray-500 mt-1">PDF • 2.4 MB</p>
                        <div className="flex items-center gap-2 mt-2">
                          <button className="text-primary-600 text-sm hover:underline">
                            View
                          </button>
                          <button className="text-primary-600 text-sm hover:underline">
                            Download
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="p-6 border-t border-gray-200 dark:border-tertiary-600 bg-gray-50 dark:bg-tertiary-800">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-secondary-600 dark:text-secondary-400">
              <AlertTriangle size={16} />
              <span className="text-sm">All investigation actions are logged and audited</span>
            </div>
            <div className="flex gap-3">
              <button onClick={onClose} className="btn btn-tertiary">
                Close
              </button>
              <button className="btn btn-primary flex items-center gap-2">
                <span>Continue Investigation</span>
                <ArrowRight size={16} />
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default InvestigateModal;