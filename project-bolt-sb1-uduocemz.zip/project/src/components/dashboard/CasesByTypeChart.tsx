import React from 'react';
import { Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Link } from 'react-router-dom';
import { ArrowUpRight } from 'lucide-react';

ChartJS.register(ArcElement, Tooltip, Legend);

const CasesByTypeChart: React.FC = () => {
  const data = {
    labels: ['Fraud', 'Money Laundering', 'Embezzlement', 'Corruption', 'Tax Evasion', 'Cybercrime'],
    datasets: [
      {
        data: [35, 25, 15, 12, 8, 5],
        backgroundColor: [
          'rgba(26, 176, 28, 0.8)', // Kenya Green
          'rgba(239, 68, 68, 0.8)', // Kenya Red
          'rgba(34, 34, 34, 0.8)', // Kenya Black
          'rgba(255, 206, 16, 0.8)', // Kenya Gold
          'rgba(96, 165, 250, 0.8)', // Blue
          'rgba(139, 92, 246, 0.8)', // Purple
        ],
        borderColor: [
          'rgba(26, 176, 28, 1)',
          'rgba(239, 68, 68, 1)',
          'rgba(34, 34, 34, 1)',
          'rgba(255, 206, 16, 1)',
          'rgba(96, 165, 250, 1)',
          'rgba(139, 92, 246, 1)',
        ],
        borderWidth: 2,
        hoverOffset: 15,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    cutout: '65%',
    layout: {
      padding: 20
    },
    plugins: {
      legend: {
        position: 'right' as const,
        labels: {
          padding: 20,
          usePointStyle: true,
          pointStyle: 'circle',
          font: {
            size: 12,
            weight: '500' as const,
          },
          generateLabels: (chart: any) => {
            const datasets = chart.data.datasets;
            return chart.data.labels.map((label: string, index: number) => ({
              text: `${label} (${datasets[0].data[index]}%)`,
              fillStyle: datasets[0].backgroundColor[index],
              strokeStyle: datasets[0].borderColor[index],
              lineWidth: 2,
              hidden: false,
              index: index,
            }));
          },
        },
      },
      tooltip: {
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        padding: 12,
        titleFont: {
          size: 14,
          weight: 'bold' as const,
        },
        bodyFont: {
          size: 13,
        },
        callbacks: {
          label: function(context: any) {
            const label = context.label || '';
            const value = context.raw || 0;
            const total = context.dataset.data.reduce((a: number, b: number) => a + b, 0);
            const percentage = Math.round((value / total) * 100);
            return `${label}: ${value} cases (${percentage}%)`;
          }
        }
      }
    },
  };

  return (
    <div className="relative h-full">
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-center">
          <div className="text-3xl font-bold text-tertiary-800 dark:text-white">100</div>
          <div className="text-sm text-gray-500 dark:text-gray-400">Total Cases</div>
        </div>
      </div>
      <div className="absolute top-0 right-0">
        <Link
          to="/cases"
          className="text-sm text-primary-600 dark:text-primary-400 hover:underline flex items-center gap-1"
        >
          View All Cases
          <ArrowUpRight size={14} />
        </Link>
      </div>
      <div className="h-[400px] flex items-center justify-center">
        <Doughnut data={data} options={options} />
      </div>
      <div className="mt-4 grid grid-cols-2 md:grid-cols-3 gap-4">
        {data.labels.map((label, index) => (
          <Link
            key={label}
            to={`/crimes/${label.toLowerCase().replace(' ', '-')}`}
            className="p-3 bg-gray-50 dark:bg-tertiary-800 rounded-lg hover:bg-gray-100 dark:hover:bg-tertiary-700 transition-colors"
          >
            <div className="flex items-center gap-2">
              <div
                className="w-3 h-3 rounded-full"
                style={{ backgroundColor: data.datasets[0].backgroundColor[index] }}
              ></div>
              <span className="font-medium">{label}</span>
            </div>
            <div className="mt-1 text-sm text-gray-500 dark:text-gray-400">
              {data.datasets[0].data[index]} cases
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default CasesByTypeChart;