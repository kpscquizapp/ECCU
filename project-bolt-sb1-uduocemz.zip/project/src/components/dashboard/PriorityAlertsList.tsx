import React from 'react';
import { AlertTriangle, ArrowUpRight, DollarSign, Building, RefreshCw } from 'lucide-react';
import { Link } from 'react-router-dom';

interface Alert {
  id: number;
  title: string;
  description: string;
  risk: 'high' | 'medium' | 'low';
  type: 'transaction' | 'entity' | 'pattern';
  isNew: boolean;
}

const PriorityAlertsList: React.FC = () => {
  // Mock data for alerts
  const alerts: Alert[] = [
    {
      id: 1,
      title: 'Unusual Transaction Pattern',
      description: 'Multiple high-value transactions to offshore accounts within 24 hours',
      risk: 'high',
      type: 'transaction',
      isNew: true,
    },
    {
      id: 2,
      title: 'Suspicious Entity',
      description: 'Company registered in known tax haven with limited transaction history',
      risk: 'high',
      type: 'entity',
      isNew: true,
    },
    {
      id: 3,
      title: 'Transaction Layering',
      description: 'Multiple transfers between related accounts to obscure source of funds',
      risk: 'medium',
      type: 'pattern',
      isNew: false,
    },
    {
      id: 4,
      title: 'Smurfing Detection',
      description: 'Multiple small deposits below reporting threshold from related sources',
      risk: 'medium',
      type: 'transaction',
      isNew: false,
    },
  ];

  const getIcon = (type: Alert['type']) => {
    switch (type) {
      case 'transaction':
        return <DollarSign size={18} />;
      case 'entity':
        return <Building size={18} />;
      case 'pattern':
        return <RefreshCw size={18} />;
      default:
        return <AlertTriangle size={18} />;
    }
  };

  const getRiskClass = (risk: Alert['risk']) => {
    switch (risk) {
      case 'high':
        return 'bg-secondary-50 text-secondary-700 dark:bg-secondary-900/20 dark:text-secondary-400';
      case 'medium':
        return 'bg-accent-50 text-accent-700 dark:bg-accent-900/20 dark:text-accent-400';
      case 'low':
        return 'bg-green-50 text-green-700 dark:bg-green-900/20 dark:text-green-400';
      default:
        return 'bg-gray-50 text-gray-700 dark:bg-gray-900/20 dark:text-gray-400';
    }
  };

  return (
    <div className="space-y-3">
      {alerts.map((alert) => (
        <div 
          key={alert.id}
          className={`p-3 rounded-lg border border-gray-100 dark:border-tertiary-600 hover:border-gray-200 dark:hover:border-tertiary-500 transition-colors ${
            alert.isNew ? 'bg-primary-50/50 dark:bg-primary-900/10' : ''
          }`}
        >
          <div className="flex items-start justify-between mb-2">
            <div className="flex items-center space-x-2">
              <div className={`p-1.5 rounded ${getRiskClass(alert.risk)}`}>
                {getIcon(alert.type)}
              </div>
              <h4 className="font-medium">{alert.title}</h4>
            </div>
            {alert.isNew && (
              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800 dark:bg-primary-900/30 dark:text-primary-300">
                New
              </span>
            )}
          </div>
          <p className="text-sm text-gray-600 dark:text-gray-300 ml-9 mb-2">{alert.description}</p>
          <div className="flex justify-end">
            <Link
              to="#"
              className="text-xs flex items-center text-primary-600 dark:text-primary-400 hover:underline"
            >
              <span>Investigate</span>
              <ArrowUpRight size={14} className="ml-1" />
            </Link>
          </div>
        </div>
      ))}
    </div>
  );
};

export default PriorityAlertsList;