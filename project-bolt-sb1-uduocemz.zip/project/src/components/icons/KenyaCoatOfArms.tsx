import React from 'react';

interface KenyaCoatOfArmsProps {
  className?: string;
}

const KenyaCoatOfArms: React.FC<KenyaCoatOfArmsProps> = ({ className = 'w-10 h-10' }) => {
  return (
    <svg
      viewBox="0 0 240 240"
      className={className}
      xmlns="http://www.w3.org/2000/svg"
    >
      <g transform="translate(0 -20)">
        {/* Shield */}
        <path
          d="M120 35c-50 0-90 20-90 45v90c0 35 40 65 90 65s90-30 90-65V80c0-25-40-45-90-45z"
          fill="#fff"
          stroke="#000"
          strokeWidth="2"
        />
        
        {/* Kenya flag colors on shield */}
        <path
          d="M120 45c-45 0-80 15-80 35v75c0 30 35 55 80 55s80-25 80-55V80c0-20-35-35-80-35z"
          fill="#1ab01c" // Kenya green
        />
        
        <path
          d="M50 80c0-15 30-25 70-25s70 10 70 25v75c0 25-30 45-70 45s-70-20-70-45V80z"
          fill="#fff"
        />
        
        <path
          d="M60 85c0-10 25-20 60-20s60 10 60 20v65c0 20-25 35-60 35s-60-15-60-35V85z"
          fill="#ef4444" // Kenya red
        />
        
        <path
          d="M70 90c0-8 20-15 50-15s50 7 50 15v55c0 15-20 30-50 30s-50-15-50-30V90z"
          fill="#000"
        />
        
        {/* Crossed spears */}
        <path
          d="M90 75l60 120M150 75l-60 120"
          stroke="#ffce10" // Kenya gold
          strokeWidth="8"
          fill="none"
        />
        
        {/* Shield emblem */}
        <circle cx="120" cy="135" r="25" fill="#ffce10" /> {/* Kenya gold */}
        
        {/* Rooster at the top */}
        <path
          d="M120 25c-5 0-9 2-12 5 3-1 6-1.5 9-1.5 5 0 10 2 13 5 3-3 7-5 12-5-3-2-7-3.5-12-3.5-3 0-7 1-10 3"
          fill="#ef4444" // Kenya red
        />
        
        {/* Supporters (lions) - simplified */}
        <path
          d="M40 120c-5 0-10 5-10 10s5 10 10 10c3 0 5-1 7-3 0 4 2 8 5 10 4 3 8 3 12 0 3-2 5-6 5-10v-14c0-4-2-8-5-10-4-3-8-3-12 0-2 2-4 5-5 9-2-1-4-2-7-2z"
          fill="#ffce10" // Kenya gold
        />
        
        <path
          d="M200 120c5 0 10 5 10 10s-5 10-10 10c-3 0-5-1-7-3 0 4-2 8-5 10-4 3-8 3-12 0-3-2-5-6-5-10v-14c0-4 2-8 5-10 4-3 8-3 12 0 2 2 4 5 5 9 2-1 4-2 7-2z"
          fill="#ffce10" // Kenya gold
        />
        
        {/* Base with "Harambee" */}
        <path
          d="M40 190h160v15H40z"
          fill="#ffce10" // Kenya gold
        />
        
        <text
          x="120"
          y="202"
          textAnchor="middle"
          fontSize="10"
          fontWeight="bold"
          fill="#000"
        >
          HARAMBEE
        </text>
      </g>
    </svg>
  );
};

export default KenyaCoatOfArms;