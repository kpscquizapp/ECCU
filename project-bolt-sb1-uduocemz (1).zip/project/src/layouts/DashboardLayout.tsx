import React, { useState } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard,
  FileSearch,
  BarChart3,
  BookCheck,
  Bell,
  Settings,
  LogOut,
  Menu,
  X,
  ChevronDown,
  Moon,
  Sun,
  Shield,
  Building2,
  Banknote,
  Coins,
  Receipt,
  Bot,
  Send,
  AlertTriangle,
  FileText,
  Search,
  Brain,
  Sparkles,
  MessageSquare,
  RefreshCw,
} from 'lucide-react';
import KenyaCoatOfArms from '../components/icons/KenyaCoatOfArms';

const DashboardLayout: React.FC = () => {
  const { user, logout } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isCrimeTypesOpen, setIsCrimeTypesOpen] = useState(false);
  const [isChatbotOpen, setIsChatbotOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState([
    {
      type: 'bot',
      content: "Hello! I'm your AI assistant. How can I help you with your investigation today?",
      timestamp: new Date(),
    },
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const navigate = useNavigate();

  const mockNotifications = [
    {
      id: 1,
      title: 'New case assigned',
      message: 'Case #4872 has been assigned to you by James Muthoni',
      time: '2 hours ago',
      isRead: false,
    },
    {
      id: 2,
      title: 'Transaction alert',
      message: 'Suspicious transaction pattern detected in Case #4865',
      time: '5 hours ago',
      isRead: false,
    },
    {
      id: 3,
      title: 'Report ready',
      message: 'The monthly compliance report is ready for review',
      time: '1 day ago',
      isRead: true,
    },
  ];

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  // Mock function to simulate AI response
  const handleSendMessage = () => {
    if (!inputMessage.trim()) return;

    // Add user message
    setChatMessages(prev => [...prev, {
      type: 'user',
      content: inputMessage,
      timestamp: new Date(),
    }]);

    setIsProcessing(true);

    // Simulate AI processing
    setTimeout(() => {
      let response = '';
      
      // Context-aware responses based on user input
      if (inputMessage.toLowerCase().includes('risk')) {
        response = "Based on my analysis of the current case data, I've identified several risk factors: 1) Unusual transaction patterns in offshore accounts, 2) Multiple shell companies with complex ownership structures, 3) Significant discrepancies in financial statements. Would you like me to generate a detailed risk assessment report?";
      } else if (inputMessage.toLowerCase().includes('evidence')) {
        response = "I can help analyze evidence using our forensic tools. Would you like me to: 1) Run pattern analysis on financial transactions, 2) Check for document authenticity, or 3) Perform entity relationship mapping?";
      } else if (inputMessage.toLowerCase().includes('pattern')) {
        response = "I've detected several suspicious patterns in recent transactions: 1) Structured deposits just below reporting thresholds, 2) Circular transactions between related entities, 3) Unusual timing of high-value transfers. Should I prepare a detailed analysis report?";
      } else if (inputMessage.toLowerCase().includes('recommend')) {
        response = "Based on the current case data, I recommend: 1) Expanding the investigation to include recently identified shell companies, 2) Conducting a detailed audit of transactions from Q3 2024, 3) Interviewing key witnesses identified through network analysis. Would you like me to elaborate on any of these recommendations?";
      } else {
        response = "I can assist you with: 1) Risk assessment, 2) Pattern analysis, 3) Evidence evaluation, 4) Entity relationship mapping, or 5) Generating investigation reports. What would you like to focus on?";
      }

      setChatMessages(prev => [...prev, {
        type: 'bot',
        content: response,
        timestamp: new Date(),
      }]);
      setIsProcessing(false);
    }, 1500);

    setInputMessage('');
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-tertiary-800 text-tertiary-800 dark:text-white">
      {/* Header */}
      <header className="bg-white dark:bg-tertiary-700 shadow-sm z-10">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center">
            <button 
              onClick={toggleSidebar}
              className="mr-4 p-2 rounded-md hover:bg-gray-100 dark:hover:bg-tertiary-600 transition-colors"
            >
              {isSidebarOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
            <div className="flex items-center space-x-3">
              <KenyaCoatOfArms className="h-8 w-8" />
              <span className="font-display text-xl font-semibold">ECCU Forensics</span>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* Theme toggle */}
            <button 
              onClick={toggleTheme} 
              className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-tertiary-600 transition-colors"
            >
              {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
            </button>
            
            {/* Notifications */}
            <div className="relative">
              <button
                className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-tertiary-600 transition-colors relative"
                onClick={() => {
                  setIsNotificationsOpen(!isNotificationsOpen);
                  setIsProfileOpen(false);
                }}
              >
                <Bell size={20} />
                <span className="absolute top-1 right-1 w-2 h-2 bg-secondary-500 rounded-full"></span>
              </button>
              
              <AnimatePresence>
                {isNotificationsOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    transition={{ duration: 0.2 }}
                    className="absolute right-0 mt-2 w-80 bg-white dark:bg-tertiary-700 shadow-lg rounded-md overflow-hidden z-20"
                  >
                    <div className="p-4 border-b dark:border-tertiary-600">
                      <h3 className="font-semibold">Notifications</h3>
                    </div>
                    <div className="max-h-96 overflow-y-auto">
                      {mockNotifications.map((notification) => (
                        <div 
                          key={notification.id}
                          className={`p-4 border-b dark:border-tertiary-600 hover:bg-gray-50 dark:hover:bg-tertiary-600 transition-colors ${
                            !notification.isRead ? 'bg-primary-50 dark:bg-primary-900/20' : ''
                          }`}
                        >
                          <div className="flex justify-between">
                            <h4 className="font-medium">{notification.title}</h4>
                            {!notification.isRead && (
                              <span className="w-2 h-2 bg-primary-500 rounded-full"></span>
                            )}
                          </div>
                          <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">{notification.message}</p>
                          <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">{notification.time}</p>
                        </div>
                      ))}
                    </div>
                    <div className="p-3 border-t dark:border-tertiary-600 text-center">
                      <button className="text-sm text-primary-600 dark:text-primary-400 hover:underline">
                        View all notifications
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
            
            {/* User profile */}
            <div className="relative">
              <button
                className="flex items-center space-x-3 p-2 rounded-md hover:bg-gray-100 dark:hover:bg-tertiary-600 transition-colors"
                onClick={() => {
                  setIsProfileOpen(!isProfileOpen);
                  setIsNotificationsOpen(false);
                }}
              >
                <img
                  src={user?.avatar || 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=100'}
                  alt={user?.name || 'User'}
                  className="w-8 h-8 rounded-full object-cover"
                />
                <div className="hidden md:block text-left">
                  <p className="font-medium">{user?.name || 'User'}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400 capitalize">{user?.role || 'User'}</p>
                </div>
                <ChevronDown size={16} />
              </button>
              
              <AnimatePresence>
                {isProfileOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    transition={{ duration: 0.2 }}
                    className="absolute right-0 mt-2 w-56 bg-white dark:bg-tertiary-700 shadow-lg rounded-md overflow-hidden z-20"
                  >
                    <div className="p-4 border-b dark:border-tertiary-600">
                      <p className="font-medium">{user?.name}</p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">{user?.email}</p>
                    </div>
                    <div className="py-2">
                      <button
                        className="flex items-center space-x-3 w-full px-4 py-2 text-left hover:bg-gray-100 dark:hover:bg-tertiary-600 transition-colors"
                        onClick={() => navigate('/settings')}
                      >
                        <Settings size={16} />
                        <span>Settings</span>
                      </button>
                      <button
                        className="flex items-center space-x-3 w-full px-4 py-2 text-left hover:bg-gray-100 dark:hover:bg-tertiary-600 text-secondary-600 dark:text-secondary-400 transition-colors"
                        onClick={logout}
                      >
                        <LogOut size={16} />
                        <span>Logout</span>
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </header>
      
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <AnimatePresence mode="wait">
          {isSidebarOpen && (
            <motion.aside
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 280, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="w-[280px] bg-white dark:bg-tertiary-700 shadow-sm z-10 overflow-y-auto overflow-x-hidden"
            >
              <div className="p-6">
                <div className="space-y-1">
                  <h3 className="text-xs uppercase text-gray-500 dark:text-gray-400 font-semibold tracking-wider mb-3">
                    Main
                  </h3>
                  <NavLink to="/" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                    <LayoutDashboard size={18} />
                    <span>Dashboard</span>
                  </NavLink>
                  <NavLink to="/cases" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                    <FileSearch size={18} />
                    <span>Case Management</span>
                  </NavLink>
                  
                  {/* Crime Types Dropdown */}
                  <div className="relative">
                    <button
                      onClick={() => setIsCrimeTypesOpen(!isCrimeTypesOpen)}
                      className="nav-link w-full flex items-center justify-between"
                    >
                      <div className="flex items-center">
                        <Shield size={18} />
                        <span className="ml-2">Crime Types</span>
                      </div>
                      <ChevronDown
                        size={16}
                        className={`transition-transform ${isCrimeTypesOpen ? 'rotate-180' : ''}`}
                      />
                    </button>
                    
                    <AnimatePresence>
                      {isCrimeTypesOpen && (
                        <motion.div
                          initial={{ opacity: 0, y: -10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -10 }}
                          className="pl-8 space-y-1 mt-1"
                        >
                          <NavLink to="/crimes/corporate-fraud" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                            <Building2 size={18} />
                            <span>Corporate Fraud</span>
                          </NavLink>
                          <NavLink to="/crimes/financial-scams" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                            <Banknote size={18} />
                            <span>Financial Scams</span>
                          </NavLink>
                          <NavLink to="/crimes/money-laundering" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                            <Coins size={18} />
                            <span>Money Laundering</span>
                          </NavLink>
                          <NavLink to="/crimes/embezzlement" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                            <Receipt size={18} />
                            <span>Embezzlement</span>
                          </NavLink>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                  
                  <NavLink to="/analysis" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                    <BarChart3 size={18} />
                    <span>Data Analysis</span>
                  </NavLink>
                  <NavLink to="/compliance" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                    <BookCheck size={18} />
                    <span>Compliance</span>
                  </NavLink>
                </div>
                
                <div className="mt-8 space-y-1">
                  <h3 className="text-xs uppercase text-gray-500 dark:text-gray-400 font-semibold tracking-wider mb-3">
                    Settings
                  </h3>
                  <NavLink to="/settings" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                    <Settings size={18} />
                    <span>Settings</span>
                  </NavLink>
                </div>
                
                <div className="mt-12 p-4 bg-primary-50 dark:bg-primary-900/20 rounded-lg">
                  <div className="flex items-center space-x-3 mb-3">
                    <Shield className="text-primary-600 dark:text-primary-400" size={20} />
                    <h3 className="font-medium text-primary-700 dark:text-primary-300">Security Level</h3>
                  </div>
                  <p className="text-sm text-primary-700 dark:text-primary-300 mb-3">
                    Your current security clearance allows access to Level 3 cases.
                  </p>
                  <button className="text-xs text-white bg-primary-600 hover:bg-primary-700 px-3 py-1.5 rounded-md w-full transition-colors">
                    Request Upgrade
                  </button>
                </div>
              </div>
            </motion.aside>
          )}
        </AnimatePresence>
        
        {/* Main content */}
        <main className="flex-1 overflow-y-auto p-6 relative">
          <Outlet />
          
          {/* AI Assistant Chatbot */}
          <div className="fixed bottom-6 right-6">
            <button
              onClick={() => setIsChatbotOpen(!isChatbotOpen)}
              className="btn bg-primary-500 hover:bg-primary-600 text-white p-3 rounded-full shadow-lg"
            >
              <Bot size={24} />
            </button>
            
            <AnimatePresence>
              {isChatbotOpen && (
                <motion.div
                  initial={{ opacity: 0, y: 20, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 20, scale: 0.95 }}
                  transition={{ duration: 0.2 }}
                  className="absolute bottom-16 right-0 w-96 bg-white dark:bg-tertiary-700 rounded-lg shadow-xl overflow-hidden"
                >
                  <div className="p-4 bg-primary-500 text-white">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Bot size={20} />
                        <div>
                          <h3 className="font-semibold">AI Assistant</h3>
                          <p className="text-xs text-primary-100">Powered by ECCU Forensics AI</p>
                        </div>
                      </div>
                      <button
                        onClick={() => setIsChatbotOpen(false)}
                        className="text-white/80 hover:text-white"
                      >
                        <X size={20} />
                      </button>
                    </div>
                  </div>

                  <div className="flex flex-col h-[500px]">
                    <div className="flex-1 overflow-y-auto p-4 space-y-4">
                      {chatMessages.map((message, index) => (
                        <div
                          key={index}
                          className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                        >
                          <div
                            className={`max-w-[80%] rounded-lg p-3 ${
                              message.type === 'user'
                                ? 'bg-primary-500 text-white'
                                : 'bg-gray-100 dark:bg-tertiary-600'
                            }`}
                          >
                            <p className="text-sm">{message.content}</p>
                            <p className="text-xs mt-1 opacity-70">
                              {message.timestamp.toLocaleTimeString()}
                            </p>
                          </div>
                        </div>
                      ))}
                      {isProcessing && (
                        <div className="flex justify-start">
                          <div className="bg-gray-100 dark:bg-tertiary-600 rounded-lg p-3">
                            <div className="flex items-center gap-2">
                              <RefreshCw size={16} className="animate-spin" />
                              <span className="text-sm">Analyzing...</span>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="p-4 border-t dark:border-tertiary-600 bg-gray-50 dark:bg-tertiary-800">
                      <div className="grid grid-cols-4 gap-2 mb-4">
                        <button className="p-2 text-xs text-center rounded bg-primary-50 dark:bg-primary-900/20 text-primary-700 dark:text-primary-300 hover:bg-primary-100 dark:hover:bg-primary-900/30">
                          <Search size={14} className="mx-auto mb-1" />
                          Analyze
                        </button>
                        <button className="p-2 text-xs text-center rounded bg-secondary-50 dark:bg-secondary-900/20 text-secondary-700 dark:text-secondary-300 hover:bg-secondary-100 dark:hover:bg-secondary-900/30">
                          <AlertTriangle size={14} className="mx-auto mb-1" />
                          Risks
                        </button>
                        <button className="p-2 text-xs text-center rounded bg-accent-50 dark:bg-accent-900/20 text-accent-700 dark:text-accent-300 hover:bg-accent-100 dark:hover:bg-accent-900/30">
                          <Brain size={14} className="mx-auto mb-1" />
                          Patterns
                        </button>
                        <button className="p-2 text-xs text-center rounded bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-300 hover:bg-green-100 dark:hover:bg-green-900/30">
                          <FileText size={14} className="mx-auto mb-1" />
                          Report
                        </button>
                      </div>

                      <div className="flex gap-2">
                        <input
                          type="text"
                          placeholder="Type your message..."
                          className="input flex-1"
                          value={inputMessage}
                          onChange={(e) => setInputMessage(e.target.value)}
                          onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                        />
                        <button 
                          className="btn btn-primary px-3"
                          onClick={handleSendMessage}
                          disabled={!inputMessage.trim() || isProcessing}
                        >
                          <Send size={18} />
                        </button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;