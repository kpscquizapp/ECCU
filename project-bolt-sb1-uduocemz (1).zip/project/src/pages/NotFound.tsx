import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, FileQuestion } from 'lucide-react';

const NotFound: React.FC = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-tertiary-800">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="max-w-md w-full bg-white dark:bg-tertiary-700 shadow-lg rounded-lg p-8 text-center"
      >
        <div className="flex justify-center mb-6">
          <div className="bg-primary-50 dark:bg-primary-900/20 rounded-full p-4">
            <FileQuestion size={48} className="text-primary-500 dark:text-primary-400" />
          </div>
        </div>
        
        <h1 className="text-3xl font-bold mb-2">404 - Page Not Found</h1>
        <p className="text-gray-600 dark:text-gray-300 mb-6">
          The page you are looking for doesn't exist or has been moved.
        </p>
        
        <Link 
          to="/"
          className="btn btn-primary inline-flex items-center justify-center gap-2"
        >
          <ArrowLeft size={16} />
          <span>Back to Dashboard</span>
        </Link>
        
        <p className="mt-6 text-sm text-gray-500 dark:text-gray-400">
          For assistance, please contact the ECCU IT support team.
        </p>
      </motion.div>
    </div>
  );
};

export default NotFound;