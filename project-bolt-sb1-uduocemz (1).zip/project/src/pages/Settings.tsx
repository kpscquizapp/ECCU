import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { 
  Bell, 
  Lock, 
  Shield, 
  Moon, 
  Sun, 
  Globe, 
  Mail, 
  Key,
  Smartphone,
  AlertTriangle,
  CheckCircle,
  X
} from 'lucide-react';

const Settings: React.FC = () => {
  const { user } = useAuth();
  const { theme, toggleTheme } = useTheme();
  
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [pushNotifications, setPushNotifications] = useState(true);
  const [twoFactorAuth, setTwoFactorAuth] = useState(false);
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);
  
  const handleSaveSettings = () => {
    setShowSuccessMessage(true);
    setTimeout(() => setShowSuccessMessage(false), 3000);
  };
  
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div>
        <h1 className="text-2xl font-bold">Settings</h1>
        <p className="text-gray-600 dark:text-gray-300">
          Manage your account settings and preferences
        </p>
      </div>
      
      {showSuccessMessage && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg flex items-center justify-between"
        >
          <div className="flex items-center gap-2 text-green-700 dark:text-green-300">
            <CheckCircle size={16} />
            <span>Settings saved successfully</span>
          </div>
          <button 
            onClick={() => setShowSuccessMessage(false)}
            className="text-green-700 dark:text-green-300 hover:text-green-800 dark:hover:text-green-200"
          >
            <X size={16} />
          </button>
        </motion.div>
      )}
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Profile Settings */}
        <div className="card">
          <h2 className="text-lg font-semibold mb-6">Profile Settings</h2>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Profile Photo</label>
              <div className="flex items-center space-x-4">
                <img
                  src={user?.avatar}
                  alt={user?.name}
                  className="w-16 h-16 rounded-full object-cover"
                />
                <button className="btn btn-tertiary">Change Photo</button>
              </div>
            </div>
            
            <div>
              <label htmlFor="name" className="block text-sm font-medium mb-1">Name</label>
              <input
                type="text"
                id="name"
                className="input"
                defaultValue={user?.name}
              />
            </div>
            
            <div>
              <label htmlFor="email" className="block text-sm font-medium mb-1">Email</label>
              <input
                type="email"
                id="email"
                className="input"
                defaultValue={user?.email}
              />
            </div>
            
            <div>
              <label htmlFor="role" className="block text-sm font-medium mb-1">Role</label>
              <input
                type="text"
                id="role"
                className="input"
                defaultValue={user?.role}
                disabled
              />
              <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                Contact your administrator to change roles
              </p>
            </div>
          </div>
        </div>
        
        {/* Security Settings */}
        <div className="card">
          <h2 className="text-lg font-semibold mb-6">Security Settings</h2>
          
          <div className="space-y-6">
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Lock size={20} className="text-primary-500" />
                  <h3 className="font-medium">Password</h3>
                </div>
                <button className="btn btn-tertiary">Change Password</button>
              </div>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Last changed: 30 days ago
              </p>
            </div>
            
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Key size={20} className="text-primary-500" />
                  <h3 className="font-medium">Two-Factor Authentication</h3>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    className="sr-only peer"
                    checked={twoFactorAuth}
                    onChange={(e) => setTwoFactorAuth(e.target.checked)}
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 dark:peer-focus:ring-primary-800 rounded-full peer dark:bg-tertiary-600 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary-600"></div>
                </label>
              </div>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Add an extra layer of security to your account
              </p>
            </div>
            
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Shield size={20} className="text-primary-500" />
                  <h3 className="font-medium">Security Log</h3>
                </div>
                <button className="btn btn-tertiary">View Log</button>
              </div>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Monitor your account's security activity
              </p>
            </div>
          </div>
        </div>
        
        {/* Notification Settings */}
        <div className="card">
          <h2 className="text-lg font-semibold mb-6">Notification Settings</h2>
          
          <div className="space-y-6">
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Mail size={20} className="text-primary-500" />
                  <h3 className="font-medium">Email Notifications</h3>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    className="sr-only peer"
                    checked={emailNotifications}
                    onChange={(e) => setEmailNotifications(e.target.checked)}
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 dark:peer-focus:ring-primary-800 rounded-full peer dark:bg-tertiary-600 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary-600"></div>
                </label>
              </div>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Receive email notifications for important updates
              </p>
            </div>
            
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Smartphone size={20} className="text-primary-500" />
                  <h3 className="font-medium">Push Notifications</h3>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    className="sr-only peer"
                    checked={pushNotifications}
                    onChange={(e) => setPushNotifications(e.target.checked)}
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 dark:peer-focus:ring-primary-800 rounded-full peer dark:bg-tertiary-600 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary-600"></div>
                </label>
              </div>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Get push notifications for real-time alerts
              </p>
            </div>
            
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Bell size={20} className="text-primary-500" />
                  <h3 className="font-medium">Alert Preferences</h3>
                </div>
                <button className="btn btn-tertiary">Configure</button>
              </div>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Customize your alert thresholds and preferences
              </p>
            </div>
          </div>
        </div>
        
        {/* Appearance Settings */}
        <div className="card">
          <h2 className="text-lg font-semibold mb-6">Appearance Settings</h2>
          
          <div className="space-y-6">
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  {theme === 'dark' ? (
                    <Moon size={20} className="text-primary-500" />
                  ) : (
                    <Sun size={20} className="text-primary-500" />
                  )}
                  <h3 className="font-medium">Theme</h3>
                </div>
                <button 
                  onClick={toggleTheme}
                  className="btn btn-tertiary flex items-center gap-2"
                >
                  {theme === 'dark' ? (
                    <>
                      <Sun size={16} />
                      <span>Light Mode</span>
                    </>
                  ) : (
                    <>
                      <Moon size={16} />
                      <span>Dark Mode</span>
                    </>
                  )}
                </button>
              </div>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Switch between light and dark mode
              </p>
            </div>
            
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Globe size={20} className="text-primary-500" />
                  <h3 className="font-medium">Language</h3>
                </div>
                <select className="input w-40">
                  <option value="en">English</option>
                  <option value="sw">Swahili</option>
                </select>
              </div>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Choose your preferred language
              </p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Session Information */}
      <div className="card bg-secondary-50 dark:bg-secondary-900/20 border border-secondary-100 dark:border-secondary-800">
        <div className="flex items-center gap-2 mb-4">
          <AlertTriangle size={20} className="text-secondary-500" />
          <h2 className="text-lg font-semibold">Active Sessions</h2>
        </div>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-white dark:bg-tertiary-700 rounded-lg">
            <div>
              <p className="font-medium">Current Session</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Last active: Just now • Nairobi, Kenya
              </p>
            </div>
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300">
              Active
            </span>
          </div>
          
          <div className="flex items-center justify-between p-4 bg-white dark:bg-tertiary-700 rounded-lg">
            <div>
              <p className="font-medium">Mobile App</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Last active: 2 hours ago • Mombasa, Kenya
              </p>
            </div>
            <button className="text-secondary-600 dark:text-secondary-400 hover:text-secondary-700 text-sm">
              Revoke Access
            </button>
          </div>
        </div>
      </div>
      
      {/* Save Button */}
      <div className="flex justify-end">
        <button 
          onClick={handleSaveSettings}
          className="btn btn-primary flex items-center gap-2"
        >
          Save Changes
        </button>
      </div>
    </motion.div>
  );
};

export default Settings;