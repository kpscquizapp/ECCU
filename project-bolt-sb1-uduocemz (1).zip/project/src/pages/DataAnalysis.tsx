import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { BarChart2, TrendingUp, PieChart, ArrowUpRight, Filter, Download, Calendar, RefreshCw } from 'lucide-react';
import { Bar, Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

const DataAnalysis: React.FC = () => {
  const [dateRange, setDateRange] = useState('7d');
  const [analysisType, setAnalysisType] = useState('transactions');

  // Mock data for transaction trends
  const transactionData = {
    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    datasets: [
      {
        label: 'Suspicious Transactions',
        data: [65, 59, 80, 81, 56, 55, 40],
        fill: true,
        backgroundColor: 'rgba(26, 176, 28, 0.1)',
        borderColor: 'rgba(26, 176, 28, 1)',
        tension: 0.4,
      },
      {
        label: 'Normal Transactions',
        data: [28, 48, 40, 19, 86, 27, 90],
        fill: true,
        backgroundColor: 'rgba(239, 68, 68, 0.1)',
        borderColor: 'rgba(239, 68, 68, 1)',
        tension: 0.4,
      },
    ],
  };

  // Mock data for risk distribution
  const riskData = {
    labels: ['High Risk', 'Medium Risk', 'Low Risk'],
    datasets: [{
      data: [30, 45, 25],
      backgroundColor: [
        'rgba(239, 68, 68, 0.8)',
        'rgba(255, 206, 16, 0.8)',
        'rgba(26, 176, 28, 0.8)',
      ],
    }],
  };

  // Chart options
  const lineOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  };

  const barOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top' as const,
      },
    },
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Data Analysis</h1>
          <p className="text-gray-600 dark:text-gray-300">
            Analyze transaction patterns and risk indicators
          </p>
        </div>
        <div className="flex space-x-3">
          <button className="btn btn-tertiary flex items-center gap-2">
            <Download size={16} />
            <span>Export</span>
          </button>
          <button className="btn btn-primary flex items-center gap-2">
            <RefreshCw size={16} />
            <span>Refresh Data</span>
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-4">
        <div className="flex-1 min-w-[200px]">
          <select 
            className="input"
            value={analysisType}
            onChange={(e) => setAnalysisType(e.target.value)}
          >
            <option value="transactions">Transaction Analysis</option>
            <option value="patterns">Pattern Recognition</option>
            <option value="entities">Entity Analysis</option>
          </select>
        </div>
        <div className="flex-1 min-w-[200px]">
          <select 
            className="input"
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
          >
            <option value="7d">Last 7 Days</option>
            <option value="30d">Last 30 Days</option>
            <option value="90d">Last 90 Days</option>
            <option value="1y">Last Year</option>
          </select>
        </div>
        <button className="btn btn-tertiary flex items-center gap-2">
          <Filter size={16} />
          <span>More Filters</span>
        </button>
      </div>

      {/* Analysis Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Transaction Volume</h3>
            <div className="p-2 rounded-full bg-primary-50 dark:bg-primary-900/20">
              <BarChart2 size={20} className="text-primary-500" />
            </div>
          </div>
          <div className="text-3xl font-bold mb-2">2,547</div>
          <div className="flex items-center text-sm text-green-600 dark:text-green-400">
            <TrendingUp size={16} className="mr-1" />
            <span>12% increase</span>
          </div>
        </div>

        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Average Risk Score</h3>
            <div className="p-2 rounded-full bg-secondary-50 dark:bg-secondary-900/20">
              <PieChart size={20} className="text-secondary-500" />
            </div>
          </div>
          <div className="text-3xl font-bold mb-2">76.5</div>
          <div className="flex items-center text-sm text-secondary-600 dark:text-secondary-400">
            <TrendingUp size={16} className="mr-1" />
            <span>High risk level</span>
          </div>
        </div>

        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Flagged Transactions</h3>
            <div className="p-2 rounded-full bg-accent-50 dark:bg-accent-900/20">
              <Calendar size={20} className="text-accent-500" />
            </div>
          </div>
          <div className="text-3xl font-bold mb-2">183</div>
          <div className="flex items-center text-sm text-accent-600 dark:text-accent-400">
            <TrendingUp size={16} className="mr-1" />
            <span>24 today</span>
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold">Transaction Trends</h3>
            <button className="text-sm text-primary-600 dark:text-primary-400 hover:underline flex items-center gap-1">
              Detailed View
              <ArrowUpRight size={14} />
            </button>
          </div>
          <div className="h-80">
            <Line data={transactionData} options={lineOptions} />
          </div>
        </div>

        <div className="card">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold">Risk Distribution</h3>
            <button className="text-sm text-primary-600 dark:text-primary-400 hover:underline flex items-center gap-1">
              View Details
              <ArrowUpRight size={14} />
            </button>
          </div>
          <div className="h-80">
            <Bar data={riskData} options={barOptions} />
          </div>
        </div>
      </div>

      {/* Analysis Insights */}
      <div className="card">
        <h3 className="text-lg font-semibold mb-6">Key Insights</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-4 bg-primary-50 dark:bg-primary-900/20 rounded-lg">
            <h4 className="font-medium text-primary-700 dark:text-primary-300 mb-2">
              Transaction Patterns
            </h4>
            <p className="text-sm text-gray-600 dark:text-gray-300">
              Significant increase in high-value transactions during non-business hours.
              87% correlation with previous fraud cases.
            </p>
          </div>
          
          <div className="p-4 bg-secondary-50 dark:bg-secondary-900/20 rounded-lg">
            <h4 className="font-medium text-secondary-700 dark:text-secondary-300 mb-2">
              Risk Indicators
            </h4>
            <p className="text-sm text-gray-600 dark:text-gray-300">
              Multiple accounts showing similar transaction patterns.
              Potential coordinated activity detected.
            </p>
          </div>
          
          <div className="p-4 bg-accent-50 dark:bg-accent-900/20 rounded-lg">
            <h4 className="font-medium text-accent-700 dark:text-accent-300 mb-2">
              Geographic Analysis
            </h4>
            <p className="text-sm text-gray-600 dark:text-gray-300">
              Unusual concentration of transactions in offshore jurisdictions.
              75% increase in cross-border transfers.
            </p>
          </div>
          
          <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
            <h4 className="font-medium text-green-700 dark:text-green-300 mb-2">
              Behavioral Analysis
            </h4>
            <p className="text-sm text-gray-600 dark:text-gray-300">
              New pattern of structured transactions just below reporting thresholds.
              Consistent timing suggests automated systems.
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default DataAnalysis;