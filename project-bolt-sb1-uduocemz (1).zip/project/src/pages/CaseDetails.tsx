import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowLeft,
  FileText,
  Clock,
  AlertTriangle,
  Users,
  Calendar,
  Edit,
  MessageSquare,
  PlusCircle,
  Paperclip,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  Link as LinkIcon,
  CheckCircle,
  Download,
  UserPlus,
  CalendarPlus,
  HelpCircle,
  FileOutput,
} from 'lucide-react';

// Mock case data with type-specific AI insights
const getAiInsights = (caseType: string) => {
  switch (caseType) {
    case 'Fraud':
      return [
        {
          title: 'Transaction Pattern Analysis',
          description: 'AI has identified consistent timing patterns in the suspicious transactions. All occurred between 01:00-03:00 local time on weekends.',
          confidence: 92,
        },
        {
          title: 'Document Authenticity Check',
          description: 'Digital analysis of submitted documents reveals potential manipulation of financial statements.',
          confidence: 88,
        },
        {
          title: 'Network Analysis',
          description: 'Multiple connected entities identified with similar transaction patterns suggesting coordinated fraud.',
          confidence: 95,
        },
      ];
    case 'Money Laundering':
      return [
        {
          title: 'Shell Company Detection',
          description: 'AI has identified a network of 8 shell companies with minimal business activity but high transaction volumes.',
          confidence: 94,
        },
        {
          title: 'Layering Pattern Detection',
          description: 'Complex chain of transactions detected across multiple jurisdictions to obscure source of funds.',
          confidence: 91,
        },
        {
          title: 'Beneficial Ownership Analysis',
          description: 'Hidden connections revealed between seemingly unrelated entities through shared beneficial owners.',
          confidence: 87,
        },
      ];
    case 'Embezzlement':
      return [
        {
          title: 'Access Pattern Analysis',
          description: 'Unusual system access patterns detected during non-business hours with high-value transactions.',
          confidence: 96,
        },
        {
          title: 'Authorization Override Detection',
          description: 'Multiple instances of security protocol bypasses identified in transaction approvals.',
          confidence: 89,
        },
        {
          title: 'Asset Movement Analysis',
          description: 'Systematic pattern of small transfers aggregating to significant amounts over time.',
          confidence: 93,
        },
      ];
    case 'Financial Scams':
      return [
        {
          title: 'Communication Pattern Analysis',
          description: 'AI detected similar linguistic patterns across multiple fraudulent investment proposals.',
          confidence: 90,
        },
        {
          title: 'Victim Profile Analysis',
          description: 'Common characteristics identified among targeted victims suggesting systematic targeting.',
          confidence: 85,
        },
        {
          title: 'Fund Flow Analysis',
          description: 'Rapid movement of funds through multiple accounts before withdrawal at specific locations.',
          confidence: 94,
        },
      ];
    default:
      return [
        {
          title: 'Risk Assessment',
          description: 'General risk analysis based on transaction patterns and entity behavior.',
          confidence: 85,
        },
        {
          title: 'Entity Connection Analysis',
          description: 'Analysis of relationships between involved entities and historical cases.',
          confidence: 82,
        },
        {
          title: 'Behavioral Pattern Detection',
          description: 'Identification of suspicious patterns in transaction and access behavior.',
          confidence: 88,
        },
      ];
  }
};

const caseData = {
  id: 4872,
  title: 'Suspected fraud scheme at Central Bank',
  description: 'Investigation into unauthorized transfers and potential insider trading at the Central Bank of Kenya. Multiple suspicious transactions have been identified involving offshore accounts.',
  status: 'active',
  priority: 'high',
  type: 'Fraud',
  assignedTo: 'John Kamau',
  dateCreated: '2025-06-01',
  lastUpdated: '2025-06-02',
  riskScore: 87,
  entities: [
    { name: 'Central Bank of Kenya', type: 'Institution', role: 'Victim' },
    { name: 'James Ochieng', type: 'Person', role: 'Suspect' },
    { name: 'Global Finance Ltd.', type: 'Company', role: 'Suspect' },
    { name: 'Cayman Islands Bank', type: 'Institution', role: 'Related Entity' },
  ],
  timeline: [
    { 
      date: '2025-06-02', 
      time: '14:32', 
      action: 'Case assigned to John Kamau', 
      user: 'James Muthoni',
      details: 'Initial investigation to focus on transaction patterns and employee access logs.'
    },
    { 
      date: '2025-06-02', 
      time: '10:15', 
      action: 'Case created', 
      user: 'Sarah Njeri',
      details: 'Case opened following alert from the transaction monitoring system.'
    },
    { 
      date: '2025-06-01', 
      time: '16:45', 
      action: 'Anomaly detected', 
      user: 'System Alert',
      details: 'Unusual pattern of transactions detected: multiple transfers to offshore accounts totaling KES 45 million.'
    },
  ],
  evidence: [
    { 
      type: 'Financial Records', 
      title: 'Transaction Log May 2025', 
      description: 'Complete transaction logs from Central Bank systems',
      dateAdded: '2025-06-02',
      addedBy: 'John Kamau'
    },
    { 
      type: 'Documentation', 
      title: 'Employee Access Logs', 
      description: 'System access records for the period of suspicious activity',
      dateAdded: '2025-06-02',
      addedBy: 'John Kamau'
    },
    { 
      type: 'Financial Records', 
      title: 'Offshore Account Details', 
      description: 'Information on recipient accounts in Cayman Islands',
      dateAdded: '2025-06-01',
      addedBy: 'Sarah Njeri'
    },
  ],
  notes: [
    {
      id: 1,
      author: 'John Kamau',
      date: '2025-06-02',
      time: '15:10',
      content: 'Initial review of transaction logs shows a pattern of transfers occurring outside normal business hours. All transactions were authorized using legitimate employee credentials, suggesting either credential theft or insider involvement.'
    },
    {
      id: 2,
      author: 'Sarah Njeri',
      date: '2025-06-01',
      time: '17:30',
      content: 'Preliminary analysis indicates these transactions bypassed standard verification protocols. Recommending full audit of security procedures and immediate freeze on all international transfers pending investigation.'
    },
  ],
  get aiInsights() {
    return getAiInsights(this.type);
  }
};

const CaseDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');
  const [isTimelineExpanded, setIsTimelineExpanded] = useState(false);
  const [newNote, setNewNote] = useState('');
  const [showActionModal, setShowActionModal] = useState<string | null>(null);
  
  const getModalContent = (actionType: string) => {
    switch (actionType) {
      case 'export':
        return {
          title: 'Export Report',
          content: (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Report Type</label>
                <select className="input">
                  <option>Full Case Report</option>
                  <option>Summary Report</option>
                  <option>Financial Analysis</option>
                  <option>Evidence Log</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Format</label>
                <select className="input">
                  <option>PDF</option>
                  <option>Excel</option>
                  <option>Word</option>
                </select>
              </div>
            </div>
          ),
        };
      case 'reassign':
        return {
          title: 'Reassign Case',
          content: (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Assign To</label>
                <select className="input">
                  <option>Sarah Njeri - Analyst</option>
                  <option>Daniel Omondi - Investigator</option>
                  <option>Rachel Wambui - Supervisor</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Priority</label>
                <select className="input">
                  <option>High</option>
                  <option>Medium</option>
                  <option>Low</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Notes</label>
                <textarea className="input" rows={3} placeholder="Add reassignment notes..."></textarea>
              </div>
            </div>
          ),
        };
      case 'meeting':
        return {
          title: 'Schedule Meeting',
          content: (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Meeting Type</label>
                <select className="input">
                  <option>Case Review</option>
                  <option>Evidence Analysis</option>
                  <option>Strategy Planning</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Date & Time</label>
                <input type="datetime-local" className="input" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Participants</label>
                <select multiple className="input h-32">
                  <option>John Kamau - Lead Investigator</option>
                  <option>Sarah Njeri - Analyst</option>
                  <option>Daniel Omondi - Compliance</option>
                  <option>Rachel Wambui - Supervisor</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Agenda</label>
                <textarea className="input" rows={3} placeholder="Meeting agenda..."></textarea>
              </div>
            </div>
          ),
        };
      case 'assistance':
        return {
          title: 'Request Assistance',
          content: (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Assistance Type</label>
                <select className="input">
                  <option>Technical Analysis</option>
                  <option>Legal Consultation</option>
                  <option>Field Investigation</option>
                  <option>Financial Analysis</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Priority</label>
                <select className="input">
                  <option>High</option>
                  <option>Medium</option>
                  <option>Low</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Description</label>
                <textarea className="input" rows={3} placeholder="Describe the assistance needed..."></textarea>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Required By</label>
                <input type="date" className="input" />
              </div>
            </div>
          ),
        };
      case 'close':
        return {
          title: 'Close Case',
          content: (
            <div className="space-y-4">
              <div className="p-4 bg-secondary-50 dark:bg-secondary-900/20 rounded-lg">
                <AlertTriangle className="text-secondary-500 mb-2" size={20} />
                <p className="text-sm text-secondary-700 dark:text-secondary-300">
                  This action will close the case. Please ensure all necessary documentation and evidence have been properly filed.
                </p>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Closure Reason</label>
                <select className="input">
                  <option>Investigation Complete</option>
                  <option>Case Resolved</option>
                  <option>Insufficient Evidence</option>
                  <option>Administrative Closure</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Closure Notes</label>
                <textarea className="input" rows={3} placeholder="Add closure notes..."></textarea>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Final Disposition</label>
                <select className="input">
                  <option>Prosecution Recommended</option>
                  <option>Administrative Action</option>
                  <option>No Further Action</option>
                  <option>Referred to Other Agency</option>
                </select>
              </div>
            </div>
          ),
        };
      default:
        return { title: '', content: null };
    }
  };

  const handleAction = (action: string) => {
    setShowActionModal(action);
  };

  const handleActionSubmit = () => {
    setShowActionModal(null);
  };

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    setNewNote('');
    alert('Note added successfully!');
  };
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300">
            <span className="w-1.5 h-1.5 rounded-full bg-green-500"></span>
            Active
          </span>
        );
      case 'pending':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-accent-100 text-accent-800 dark:bg-accent-900/30 dark:text-accent-300">
            <Clock size={12} />
            Pending
          </span>
        );
      case 'closed':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300">
            Closed
          </span>
        );
      default:
        return null;
    }
  };
  
  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'high':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-secondary-100 text-secondary-800 dark:bg-secondary-900/30 dark:text-secondary-300">
            <AlertTriangle size={12} />
            High
          </span>
        );
      case 'medium':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-accent-100 text-accent-800 dark:bg-accent-900/30 dark:text-accent-300">
            Medium
          </span>
        );
      case 'low':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300">
            Low
          </span>
        );
      default:
        return null;
    }
  };
  
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Link to="/cases" className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300">
              <ArrowLeft size={16} />
            </Link>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <FileText className="text-primary-500" />
              Case #{id}
            </h1>
          </div>
          <h2 className="text-xl font-semibold mb-2">{caseData.title}</h2>
          <div className="flex flex-wrap items-center gap-2">
            {getStatusBadge(caseData.status)}
            {getPriorityBadge(caseData.priority)}
            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300">
              {caseData.type}
            </span>
          </div>
        </div>
        
        <div className="flex flex-wrap gap-3">
          <button className="btn btn-tertiary flex items-center gap-2">
            <ExternalLink size={16} />
            <span>Export</span>
          </button>
          <button className="btn btn-secondary flex items-center gap-2">
            <MessageSquare size={16} />
            <span>Add Comment</span>
          </button>
          <button className="btn btn-primary flex items-center gap-2">
            <Edit size={16} />
            <span>Edit Case</span>
          </button>
        </div>
      </div>
      
      {/* Tabs */}
      <div className="border-b border-gray-200 dark:border-tertiary-600">
        <nav className="flex space-x-6">
          <button
            onClick={() => setActiveTab('overview')}
            className={`py-4 px-1 relative font-medium text-sm ${
              activeTab === 'overview'
                ? 'text-primary-600 dark:text-primary-400 border-b-2 border-primary-500'
                : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('evidence')}
            className={`py-4 px-1 relative font-medium text-sm ${
              activeTab === 'evidence'
                ? 'text-primary-600 dark:text-primary-400 border-b-2 border-primary-500'
                : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
            }`}
          >
            Evidence & Documents
          </button>
          <button
            onClick={() => setActiveTab('entities')}
            className={`py-4 px-1 relative font-medium text-sm ${
              activeTab === 'entities'
                ? 'text-primary-600 dark:text-primary-400 border-b-2 border-primary-500'
                : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
            }`}
          >
            Related Entities
          </button>
          <button
            onClick={() => setActiveTab('analysis')}
            className={`py-4 px-1 relative font-medium text-sm ${
              activeTab === 'analysis'
                ? 'text-primary-600 dark:text-primary-400 border-b-2 border-primary-500'
                : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
            }`}
          >
            AI Analysis
          </button>
        </nav>
      </div>
      
      {/* Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main content */}
        <div className="lg:col-span-2 space-y-6">
          {activeTab === 'overview' && (
            <>
              {/* Case description */}
              <div className="card">
                <h3 className="text-lg font-semibold mb-4">Case Description</h3>
                <p className="text-gray-700 dark:text-gray-300">{caseData.description}</p>
              </div>
              
              {/* Case timeline */}
              <div className="card">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold">Case Timeline</h3>
                  <button
                    onClick={() => setIsTimelineExpanded(!isTimelineExpanded)}
                    className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
                  >
                    {isTimelineExpanded ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
                  </button>
                </div>
                
                <div className="border-l-2 border-gray-200 dark:border-tertiary-600 ml-3 space-y-6 pt-2 pb-4">
                  {caseData.timeline.slice(0, isTimelineExpanded ? undefined : 3).map((event, index) => (
                    <div key={index} className="relative pl-8 -ml-px">
                      <div className="absolute left-0 top-1 w-5 h-5 bg-primary-100 dark:bg-primary-900/30 border-2 border-primary-500 rounded-full"></div>
                      <div className="flex flex-col sm:flex-row sm:items-start justify-between mb-1">
                        <p className="font-medium">{event.action}</p>
                        <p className="text-sm text-gray-500 dark:text-gray-400 sm:ml-4">
                          {event.date}, {event.time}
                        </p>
                      </div>
                      <p className="text-sm text-gray-700 dark:text-gray-300">{event.details}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">By {event.user}</p>
                    </div>
                  ))}
                </div>
                
                {!isTimelineExpanded && caseData.timeline.length > 3 && (
                  <button
                    onClick={() => setIsTimelineExpanded(true)}
                    className="text-sm text-primary-600 dark:text-primary-400 hover:underline flex items-center mt-2"
                  >
                    <ChevronDown size={16} className="mr-1" />
                    View full timeline ({caseData.timeline.length} events)
                  </button>
                )}
              </div>
              
              {/* Case notes */}
              <div className="card">
                <h3 className="text-lg font-semibold mb-4">Case Notes</h3>
                
                <div className="space-y-4 mb-6">
                  {caseData.notes.map((note) => (
                    <div key={note.id} className="p-4 bg-gray-50 dark:bg-tertiary-800 rounded-lg">
                      <div className="flex justify-between mb-2">
                        <h4 className="font-medium">{note.author}</h4>
                        <span className="text-sm text-gray-500 dark:text-gray-400">{note.date}, {note.time}</span>
                      </div>
                      <p className="text-gray-700 dark:text-gray-300 text-sm">{note.content}</p>
                    </div>
                  ))}
                </div>
                
                <form onSubmit={handleAddNote}>
                  <label htmlFor="note" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Add Note
                  </label>
                  <textarea
                    id="note"
                    rows={3}
                    className="input resize-none mb-3"
                    placeholder="Type your note here..."
                    value={newNote}
                    onChange={(e) => setNewNote(e.target.value)}
                  ></textarea>
                  <div className="flex justify-end">
                    <button
                      type="submit"
                      className="btn btn-primary flex items-center gap-2"
                      disabled={!newNote.trim()}
                    >
                      <PlusCircle size={16} />
                      <span>Add Note</span>
                    </button>
                  </div>
                </form>
              </div>
            </>
          )}
          
          {activeTab === 'evidence' && (
            <div className="card">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold">Evidence & Documents</h3>
                <button className="btn btn-primary flex items-center gap-2">
                  <PlusCircle size={16} />
                  <span>Add Evidence</span>
                </button>
              </div>
              
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-tertiary-600">
                  <thead>
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Type
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Title
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Description
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Date Added
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Added By
                      </th>
                      <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200 dark:divide-tertiary-600">
                    {caseData.evidence.map((item, index) => (
                      <tr key={index} className="hover:bg-gray-50 dark:hover:bg-tertiary-800">
                        <td className="px-6 py-4 whitespace-nowrap text-sm">
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300">
                            {item.type}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          {item.title}
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-500 dark:text-gray-400">
                          {item.description}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                          {item.dateAdded}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm">
                          {item.addedBy}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-right">
                          <button className="text-primary-600 dark:text-primary-400 hover:text-primary-800 dark:hover:text-primary-300 mr-3">
                            View
                          </button>
                          <button className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300">
                            <Paperclip size={16} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
          
          {activeTab === 'entities' && (
            <div className="card">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold">Related Entities</h3>
                <button className="btn btn-primary flex items-center gap-2">
                  <PlusCircle size={16} />
                  <span>Add Entity</span>
                </button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {caseData.entities.map((entity, index) => (
                  <div key={index} className="border border-gray-200 dark:border-tertiary-600 rounded-lg p-4 hover:border-primary-300 dark:hover:border-primary-500 transition-colors">
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="font-medium">{entity.name}</h4>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-xs text-gray-500 dark:text-gray-400">{entity.type}</span>
                          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300">
                            {entity.role}
                          </span>
                        </div>
                      </div>
                      
                      <button className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300">
                        <LinkIcon size={16} />
                      </button>
                    </div>
                    <div className="mt-3 pt-3 border-t border-gray-100 dark:border-tertiary-700 flex justify-between">
                      <button className="text-xs text-primary-600 dark:text-primary-400 hover:underline">
                        View Details
                      </button>
                      <button className="text-xs text-primary-600 dark:text-primary-400 hover:underline">
                        View Connections
                      </button>
                    </div>
                  </div>
                ))}
              </div>
              
              {/* Network Visualization Placeholder */}
              <div className="mt-6 border border-dashed border-gray-300 dark:border-tertiary-600 rounded-lg p-8 text-center bg-gray-50 dark:bg-tertiary-800">
                <h4 className="font-medium mb-2">Entity Relationship Network</h4>
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                  Visual representation of connections between entities related to this case.
                </p>
                <button className="btn btn-tertiary">
                  View Network Graph
                </button>
              </div>
            </div>
          )}
          
          {activeTab === 'analysis' && (
            <>
              <div className="card">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-semibold">AI Insights</h3>
                  <button className="btn btn-primary flex items-center gap-2">
                    <span>Run New Analysis</span>
                  </button>
                </div>
                
                <div className="space-y-4">
                  {caseData.aiInsights.map((insight, index) => (
                    <div key={index} className="p-4 bg-primary-50 dark:bg-primary-900/20 border border-primary-100 dark:border-primary-800 rounded-lg">
                      <div className="flex justify-between mb-2">
                        <h4 className="font-medium text-primary-700 dark:text-primary-300">{insight.title}</h4>
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary-100 text-primary-800 dark:bg-primary-800 dark:text-primary-200">
                          {insight.confidence}% Confidence
                        </span>
                      </div>
                      <p className="text-gray-700 dark:text-gray-300 text-sm">{insight.description}</p>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Risk Analysis */}
              <div className="card">
                <h3 className="text-lg font-semibold mb-4">Risk Analysis</h3>
                
                <div className="flex items-center justify-between mb-4">
                  <span className="text-sm font-medium">Overall Risk Score</span>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-secondary-100 text-secondary-800 dark:bg-secondary-900/30 dark:text-secondary-300">
                    {caseData.riskScore}/100
                  </span>
                </div>
                
                <div className="w-full h-4 bg-gray-200 dark:bg-tertiary-600 rounded-full overflow-hidden mb-6">
                  <div 
                    className="h-full bg-secondary-500"
                    style={{ width: `${caseData.riskScore}%` }}
                  ></div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-xs">Transaction Complexity</span>
                      <span className="text-xs">High</span>
                    </div>
                    <div className="w-full h-2 bg-gray-200 dark:bg-tertiary-600 rounded-full overflow-hidden">
                      <div className="h-full bg-secondary-500" style={{ width: '85%' }}></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-xs">Geographic Risk</span>
                      <span className="text-xs">Medium</span>
                    </div>
                    <div className="w-full h-2 bg-gray-200 dark:bg-tertiary-600 rounded-full overflow-hidden">
                      <div className="h-full bg-accent-500" style={{ width: '60%' }}></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-xs">Entity Background</span>
                      <span className="text-xs">High</span>
                    </div>
                    <div className="w-full h-2 bg-gray-200 dark:bg-tertiary-600 rounded-full overflow-hidden">
                      <div className="h-full bg-secondary-500" style={{ width: '90%' }}></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-xs">Pattern Recognition</span>
                      <span className="text-xs">High</span>
                    </div>
                    <div className="w-full h-2 bg-gray-200 dark:bg-tertiary-600 rounded-full overflow-hidden">
                      <div className="h-full bg-secondary-500" style={{ width: '95%' }}></div>
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
        
        {/* Sidebar */}
        <div className="space-y-6">
          {/* Case Information Card */}
          <div className="card">
            <h3 className="text-lg font-semibold mb-4">Case Information</h3>
            
            <div className="space-y-4">
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">Assigned To</p>
                <div className="flex items-center mt-1">
                  <div className="w-8 h-8 rounded-full bg-gray-200 dark:bg-tertiary-600 flex items-center justify-center mr-2">
                    <Users size={16} className="text-gray-500 dark:text-gray-400" />
                  </div>
                  <span>{caseData.assignedTo}</span>
                </div>
              </div>
              
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">Risk Score</p>
                <div className="flex items-center mt-1">
                  <div 
                    className={`px-2.5 py-1 rounded text-xs font-medium ${
                      caseData.riskScore >= 80 
                        ? 'bg-secondary-100 text-secondary-800 dark:bg-secondary-900/30 dark:text-secondary-300' 
                        : caseData.riskScore >= 60
                        ? 'bg-accent-100 text-accent-800 dark:bg-accent-900/30 dark:text-accent-300'
                        : 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300'
                    }`}
                  >
                    {caseData.riskScore}/100
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Case Type</p>
                  <p className="mt-1">{caseData.type}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Status</p>
                  <p className="mt-1 capitalize">{caseData.status}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Priority</p>
                  <p className="mt-1 capitalize">{caseData.priority}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Case ID</p>
                  <p className="mt-1">#{caseData.id}</p>
                </div>
              </div>
              
              <div className="pt-4 border-t border-gray-200 dark:border-tertiary-600">
                <div className="flex items-center gap-1 mb-2">
                  <Calendar size={16} className="text-gray-500 dark:text-gray-400" />
                  <p className="text-sm text-gray-500 dark:text-gray-400">Timeline</p>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <p className="text-sm">Date Created</p>
                    <p className="text-sm">{caseData.dateCreated}</p>
                  </div>
                  <div className="flex justify-between">
                    <p className="text-sm">Last Updated</p>
                    <p className="text-sm">{caseData.lastUpdated}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Quick Actions Card */}
          <div className="card">
            <h3 className="text-lg font-semibold mb-4">Case Actions</h3>
            <div className="grid grid-cols-1 gap-3">
              <button
                onClick={() => handleAction('export')}
                className="btn w-full bg-white dark:bg-tertiary-600 border border-gray-200 dark:border-tertiary-500 text-left flex items-center gap-3 hover:bg-gray-50 dark:hover:bg-tertiary-500"
              >
                <FileOutput size={18} />
                <div className="flex-1">
                  <span className="font-medium">Generate Report</span>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Export case details and analysis</p>
                </div>
              </button>

              <button
                onClick={() => handleAction('reassign')}
                className="btn w-full bg-white dark:bg-tertiary-600 border border-gray-200 dark:border-tertiary-500 text-left flex items-center gap-3 hover:bg-gray-50 dark:hover:bg-tertiary-500"
              >
                <UserPlus size={18} />
                <div className="flex-1">
                  <span className="font-medium">Reassign Case</span>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Transfer case to another investigator</p>
                </div>
              </button>

              <button
                onClick={() => handleAction('meeting')}
                className="btn w-full bg-white dark:bg-tertiary-600 border border-gray-200 dark:border-tertiary-500 text-left flex items-center gap-3 hover:bg-gray-50 dark:hover:bg-tertiary-500"
              >
                <CalendarPlus size={18} />
                <div className="flex-1">
                  <span className="font-medium">Schedule Meeting</span>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Plan case review or strategy session</p>
                </div>
              </button>

              <button
                onClick={() => handleAction('assistance')}
                className="btn w-full bg-white dark:bg-tertiary-600 border border-gray-200 dark:border-tertiary-500 text-left flex items-center gap-3 hover:bg-gray-50 dark:hover:bg-tertiary-500"
              >
                <HelpCircle size={18} />
                <div className="flex-1">
                  <span className="font-medium">Request Assistance</span>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Get help from specialists or experts</p>
                </div>
              </button>

              <button
                onClick={() => handleAction('close')}
                className="btn w-full bg-secondary-50 dark:bg-secondary-900/20 border border-secondary-100 dark:border-secondary-800 text-secondary-700 dark:text-secondary-300 text-left flex items-center gap-3 hover:bg-secondary-100 dark:hover:bg-secondary-900/30"
              >
                <CheckCircle size={18} />
                <div className="flex-1">
                  <span className="font-medium">Close Case</span>
                  <p className="text-xs text-secondary-600 dark:text-secondary-400">Mark case as complete</p>
                </div>
              </button>
            </div>
          </div>

          {/* Related Cases Card */}
          <div className="card">
            <h3 className="text-lg font-semibold mb-4">Related Cases</h3>
            
            <div className="space-y-3">
              <div className="p-3 border border-gray-200 dark:border-tertiary-600 rounded-lg hover:border-primary-300 dark:hover:border-primary-500 transition-colors">
                <Link to="/cases/4865" className="font-medium text-primary-600 dark:text-primary-400 hover:underline">
                  Case #4865 - Bank insider trading scandal
                </Link>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                  Related by entity: Central Bank of Kenya
                </p>
              </div>
              
              <div className="p-3 border border-gray-200 dark:border-tertiary-600 rounded-lg hover:border-primary-300 dark:hover:border-primary-500 transition-colors">
                <Link to="/cases/4860" className="font-medium text-primary-600 dark:text-primary-400 hover:underline">
                  Case #4860 - Global Finance fraud investigation
                </Link>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                  Related by entity: Global Finance Ltd.
                </p>
              </div>
            </div>
            
            <button className="text-sm text-primary-600 dark:text-primary-400 hover:underline flex items-center mt-4">
              <PlusCircle size={14} className="mr-1" />
              Add related case
            </button>
          </div>
        </div>
      </div>

      {/* Action Modal */}
      {showActionModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="bg-white dark:bg-tertiary-700 rounded-lg shadow-xl w-full max-w-md mx-4"
          >
            <div className="p-6">
              <h3 className="text-lg font-semibold mb-4">{getModalContent(showActionModal).title}</h3>
              {getModalContent(showActionModal).content}
              <div className="flex justify-end gap-3 mt-6">
                <button
                  onClick={() => setShowActionModal(null)}
                  className="btn btn-tertiary"
                >
                  Cancel
                </button>
                <button
                  onClick={handleActionSubmit}
                  className="btn btn-primary"
                >
                  Confirm
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </motion.div>
  );
};

export default CaseDetails;