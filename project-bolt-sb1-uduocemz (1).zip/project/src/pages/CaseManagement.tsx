import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { 
  Search, 
  Filter, 
  Plus, 
  ChevronDown, 
  Clock, 
  AlertTriangle, 
  Ban,
  CheckCircle,
  FileText,
  ArrowUpDown
} from 'lucide-react';
import NewCaseModal from '../components/cases/NewCaseModal';
import InvestigateModal from '../components/cases/InvestigateModal';

interface Case {
  id: number;
  title: string;
  description: string;
  status: 'active' | 'pending' | 'closed' | 'archived';
  priority: 'high' | 'medium' | 'low';
  type: string;
  assignedTo: string;
  dateCreated: string;
  lastUpdated: string;
  riskScore: number;
}

const CaseManagement: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [isNewCaseModalOpen, setIsNewCaseModalOpen] = useState(false);
  const [isInvestigateModalOpen, setIsInvestigateModalOpen] = useState(false);
  const [selectedCase, setSelectedCase] = useState<any>(null);
  
  const cases: Case[] = [
    {
      id: 4872,
      title: 'Suspected fraud scheme at Central Bank',
      description: 'Investigation into unauthorized transfers and potential insider trading',
      status: 'active',
      priority: 'high',
      type: 'Fraud',
      assignedTo: 'John Kamau',
      dateCreated: '2025-06-01',
      lastUpdated: '2025-06-02',
      riskScore: 87,
    },
    {
      id: 4871,
      title: 'Money laundering through real estate',
      description: 'Investigation into suspicious property transactions in Nairobi',
      status: 'active',
      priority: 'high',
      type: 'Money Laundering',
      assignedTo: 'Sarah Njeri',
      dateCreated: '2025-05-28',
      lastUpdated: '2025-06-01',
      riskScore: 82,
    },
    {
      id: 4870,
      title: 'Tax evasion by offshore companies',
      description: 'Investigation into companies operating in Kenya but registered in tax havens',
      status: 'pending',
      priority: 'medium',
      type: 'Tax Evasion',
      assignedTo: 'Daniel Omondi',
      dateCreated: '2025-05-25',
      lastUpdated: '2025-05-30',
      riskScore: 76,
    },
    {
      id: 4869,
      title: 'Embezzlement at Ministry of Finance',
      description: 'Investigation into misappropriation of public funds',
      status: 'active',
      priority: 'high',
      type: 'Embezzlement',
      assignedTo: 'Rachel Wambui',
      dateCreated: '2025-05-20',
      lastUpdated: '2025-05-28',
      riskScore: 91,
    },
    {
      id: 4868,
      title: 'Counterfeit currency operation',
      description: 'Investigation into a high-quality counterfeit Kenyan shilling operation',
      status: 'closed',
      priority: 'medium',
      type: 'Counterfeiting',
      assignedTo: 'John Kamau',
      dateCreated: '2025-05-15',
      lastUpdated: '2025-05-27',
      riskScore: 65,
    },
    {
      id: 4867,
      title: 'Procurement corruption at parastatals',
      description: 'Investigation into bid rigging and kickbacks in government tenders',
      status: 'active',
      priority: 'medium',
      type: 'Corruption',
      assignedTo: 'Sarah Njeri',
      dateCreated: '2025-05-10',
      lastUpdated: '2025-05-25',
      riskScore: 78,
    },
    {
      id: 4866,
      title: 'Cryptocurrency scam targeting farmers',
      description: 'Investigation into fraudulent investment scheme targeting agricultural sector',
      status: 'pending',
      priority: 'low',
      type: 'Cybercrime',
      assignedTo: 'Daniel Omondi',
      dateCreated: '2025-05-05',
      lastUpdated: '2025-05-20',
      riskScore: 58,
    },
    {
      id: 4865,
      title: 'Bank insider trading scandal',
      description: 'Investigation into employees leaking confidential information for profit',
      status: 'archived',
      priority: 'medium',
      type: 'Insider Trading',
      assignedTo: 'Rachel Wambui',
      dateCreated: '2025-05-01',
      lastUpdated: '2025-05-18',
      riskScore: 62,
    },
  ];

  const handleNewCase = (caseData: any) => {
    console.log('New case data:', caseData);
    setIsNewCaseModalOpen(false);
  };

  const handleInvestigate = (caseItem: any) => {
    setSelectedCase(caseItem);
    setIsInvestigateModalOpen(true);
  };
  
  const filteredCases = cases.filter((caseItem) => {
    if (statusFilter !== 'all' && caseItem.status !== statusFilter) {
      return false;
    }
    
    if (priorityFilter !== 'all' && caseItem.priority !== priorityFilter) {
      return false;
    }
    
    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase();
      return (
        caseItem.title.toLowerCase().includes(searchLower) ||
        caseItem.description.toLowerCase().includes(searchLower) ||
        caseItem.type.toLowerCase().includes(searchLower) ||
        caseItem.assignedTo.toLowerCase().includes(searchLower) ||
        caseItem.id.toString().includes(searchLower)
      );
    }
    
    return true;
  });
  
  const getStatusBadge = (status: Case['status']) => {
    switch (status) {
      case 'active':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300">
            <span className="w-1.5 h-1.5 rounded-full bg-green-500"></span>
            Active
          </span>
        );
      case 'pending':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-accent-100 text-accent-800 dark:bg-accent-900/30 dark:text-accent-300">
            <Clock size={12} />
            Pending
          </span>
        );
      case 'closed':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300">
            <CheckCircle size={12} />
            Closed
          </span>
        );
      case 'archived':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300">
            <Ban size={12} />
            Archived
          </span>
        );
      default:
        return null;
    }
  };
  
  const getPriorityBadge = (priority: Case['priority']) => {
    switch (priority) {
      case 'high':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-secondary-100 text-secondary-800 dark:bg-secondary-900/30 dark:text-secondary-300">
            <AlertTriangle size={12} />
            High
          </span>
        );
      case 'medium':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-accent-100 text-accent-800 dark:bg-accent-900/30 dark:text-accent-300">
            Medium
          </span>
        );
      case 'low':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300">
            Low
          </span>
        );
      default:
        return null;
    }
  };
  
  const getRiskScoreBadge = (score: number) => {
    let colorClass = '';
    if (score >= 80) {
      colorClass = 'bg-secondary-100 text-secondary-800 dark:bg-secondary-900/30 dark:text-secondary-300';
    } else if (score >= 60) {
      colorClass = 'bg-accent-100 text-accent-800 dark:bg-accent-900/30 dark:text-accent-300';
    } else {
      colorClass = 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300';
    }
    
    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${colorClass}`}>
        {score}
      </span>
    );
  };
  
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="space-y-6"
    >
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Case Management</h1>
          <p className="text-gray-600 dark:text-gray-300">
            Manage and track all investigation cases
          </p>
        </div>
        <button 
          className="btn btn-primary flex items-center gap-2"
          onClick={() => setIsNewCaseModalOpen(true)}
        >
          <Plus size={16} />
          <span>New Case</span>
        </button>
      </div>
      
      <div className="flex flex-col md:flex-row gap-4">
        <div className="w-full md:w-2/3 relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search size={18} className="text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="Search cases by title, description, type, or ID..."
            className="input pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="w-full md:w-1/3 flex gap-3">
          <div className="relative flex-1">
            <button 
              className="btn w-full bg-white dark:bg-tertiary-700 border border-gray-300 dark:border-tertiary-600 text-left flex items-center justify-between"
              onClick={() => setIsFilterOpen(!isFilterOpen)}
            >
              <span className="flex items-center gap-2">
                <Filter size={16} />
                <span>Filters</span>
              </span>
              <ChevronDown size={16} />
            </button>
            
            {isFilterOpen && (
              <div className="absolute z-10 mt-2 w-full bg-white dark:bg-tertiary-700 shadow-lg rounded-md p-4 border border-gray-200 dark:border-tertiary-600 space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Status</label>
                  <select
                    className="input"
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                  >
                    <option value="all">All Statuses</option>
                    <option value="active">Active</option>
                    <option value="pending">Pending</option>
                    <option value="closed">Closed</option>
                    <option value="archived">Archived</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Priority</label>
                  <select
                    className="input"
                    value={priorityFilter}
                    onChange={(e) => setPriorityFilter(e.target.value)}
                  >
                    <option value="all">All Priorities</option>
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                  </select>
                </div>
                <div className="flex justify-end">
                  <button 
                    className="text-sm text-primary-600 dark:text-primary-400 hover:underline"
                    onClick={() => {
                      setStatusFilter('all');
                      setPriorityFilter('all');
                    }}
                  >
                    Reset Filters
                  </button>
                </div>
              </div>
            )}
          </div>
          
          <select className="input flex-1">
            <option value="newest">Newest First</option>
            <option value="oldest">Oldest First</option>
            <option value="priority">Priority (High-Low)</option>
            <option value="risk">Risk Score (High-Low)</option>
          </select>
        </div>
      </div>
      
      <div className="bg-white dark:bg-tertiary-700 rounded-lg shadow">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-tertiary-600">
            <thead className="bg-gray-50 dark:bg-tertiary-800">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  <div className="flex items-center gap-1">
                    Case ID
                    <ArrowUpDown size={14} className="cursor-pointer" />
                  </div>
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  <div className="flex items-center gap-1">
                    Title
                    <ArrowUpDown size={14} className="cursor-pointer" />
                  </div>
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Status
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Priority
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Type
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Assigned To
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  <div className="flex items-center gap-1">
                    Last Updated
                    <ArrowUpDown size={14} className="cursor-pointer" />
                  </div>
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  <div className="flex items-center gap-1">
                    Risk Score
                    <ArrowUpDown size={14} className="cursor-pointer" />
                  </div>
                </th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-tertiary-700 divide-y divide-gray-200 dark:divide-tertiary-600">
              {filteredCases.map((caseItem) => (
                <tr 
                  key={caseItem.id}
                  className="hover:bg-gray-50 dark:hover:bg-tertiary-600/50 transition-colors"
                >
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <Link to={`/cases/${caseItem.id}`} className="text-primary-600 dark:text-primary-400 hover:underline flex items-center gap-2">
                      <FileText size={16} />
                      #{caseItem.id}
                    </Link>
                  </td>
                  <td className="px-6 py-4 text-sm">
                    <div className="font-medium">{caseItem.title}</div>
                    <div className="text-gray-500 dark:text-gray-400 text-xs mt-1 line-clamp-1">
                      {caseItem.description}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    {getStatusBadge(caseItem.status)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    {getPriorityBadge(caseItem.priority)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    {caseItem.type}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    {caseItem.assignedTo}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                    {caseItem.lastUpdated}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    {getRiskScoreBadge(caseItem.riskScore)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-right">
                    <button
                      onClick={() => handleInvestigate(caseItem)}
                      className="text-primary-600 dark:text-primary-400 hover:text-primary-800 dark:hover:text-primary-300 mr-3"
                    >
                      Investigate
                    </button>
                    <Link 
                      to={`/cases/${caseItem.id}`}
                      className="text-primary-600 dark:text-primary-400 hover:text-primary-800 dark:hover:text-primary-300"
                    >
                      View
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {filteredCases.length === 0 && (
          <div className="py-8 text-center">
            <p className="text-gray-500 dark:text-gray-400">No cases found matching your filters.</p>
          </div>
        )}
        
        <div className="px-6 py-3 flex items-center justify-between border-t border-gray-200 dark:border-tertiary-600">
          <div className="flex-1 flex justify-between sm:hidden">
            <button className="btn btn-tertiary">Previous</button>
            <button className="btn btn-tertiary">Next</button>
          </div>
          <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
            <div>
              <p className="text-sm text-gray-700 dark:text-gray-300">
                Showing <span className="font-medium">1</span> to <span className="font-medium">{filteredCases.length}</span> of{' '}
                <span className="font-medium">{filteredCases.length}</span> results
              </p>
            </div>
            <div>
              <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                <button className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 dark:border-tertiary-600 bg-white dark:bg-tertiary-700 text-sm font-medium text-gray-500 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-tertiary-600">
                  <span className="sr-only">Previous</span>
                  <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                    <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </button>
                <button className="relative inline-flex items-center px-4 py-2 border border-gray-300 dark:border-tertiary-600 bg-primary-50 dark:bg-primary-900/20 text-sm font-medium text-primary-600 dark:text-primary-400">
                  1
                </button>
                <button className="relative inline-flex items-center px-4 py-2 border border-gray-300 dark:border-tertiary-600 bg-white dark:bg-tertiary-700 text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-tertiary-600">
                  2
                </button>
                <button className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 dark:border-tertiary-600 bg-white dark:bg-tertiary-700 text-sm font-medium text-gray-500 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-tertiary-600">
                  <span className="sr-only">Next</span>
                  <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                    <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
                  </svg>
                </button>
              </nav>
            </div>
          </div>
        </div>
      </div>

      <NewCaseModal
        isOpen={isNewCaseModalOpen}
        onClose={() => setIsNewCaseModalOpen(false)}
        onSubmit={handleNewCase}
      />

      {selectedCase && (
        <InvestigateModal
          isOpen={isInvestigateModalOpen}
          onClose={() => setIsInvestigateModalOpen(false)}
          caseId={selectedCase.id}
          caseTitle={selectedCase.title}
        />
      )}
    </motion.div>
  );
};

export default CaseManagement;