import React from 'react';
import { motion } from 'framer-motion';

const RiskScoreWidget: React.FC = () => {
  const riskScore = 73; // 0-100 scale
  const riskLevel = riskScore >= 75 ? 'High' : riskScore >= 50 ? 'Medium' : 'Low';
  
  const getColorClass = () => {
    if (riskScore >= 75) return 'text-secondary-600 dark:text-secondary-400';
    if (riskScore >= 50) return 'text-accent-600 dark:text-accent-400';
    return 'text-green-600 dark:text-green-400';
  };
  
  const getIndicatorColor = () => {
    if (riskScore >= 75) return 'from-secondary-500 to-secondary-600';
    if (riskScore >= 50) return 'from-accent-500 to-accent-600';
    return 'from-green-500 to-green-600';
  };

  return (
    <div className="flex flex-col items-center">
      <div className="relative w-48 h-48 mb-6">
        {/* Base circle (gray track) */}
        <div className="absolute inset-0 rounded-full border-8 border-gray-200 dark:border-tertiary-600"></div>
        
        {/* Progress circle with gradient */}
        <svg className="absolute inset-0 w-full h-full rotate-[270deg]" viewBox="0 0 100 100">
          <motion.circle
            initial={{ strokeDasharray: '0 283' }}
            animate={{ 
              strokeDasharray: `${(riskScore / 100) * 283} 283` 
            }}
            transition={{ duration: 1, delay: 0.5 }}
            cx="50"
            cy="50"
            r="45"
            fill="transparent"
            stroke={`url(#risk-gradient-${riskLevel.toLowerCase()})`}
            strokeWidth="8"
            strokeLinecap="round"
            className="drop-shadow-md"
          />
          
          {/* Gradient definition */}
          <defs>
            <linearGradient id={`risk-gradient-${riskLevel.toLowerCase()}`} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" className={`stop-${getIndicatorColor().split(' ')[0]}`} />
              <stop offset="100%" className={`stop-${getIndicatorColor().split(' ')[1]}`} />
            </linearGradient>
          </defs>
        </svg>
        
        {/* Center content */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <motion.span 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 1 }}
            className={`text-4xl font-bold ${getColorClass()}`}
          >
            {riskScore}
          </motion.span>
          <span className="text-sm text-gray-500 dark:text-gray-400">Risk Score</span>
        </div>
      </div>
      
      <div className="text-center">
        <h3 className={`text-xl font-semibold ${getColorClass()}`}>{riskLevel} Risk Level</h3>
        <p className="text-sm text-gray-600 dark:text-gray-300 mt-2">
          Based on current case portfolio and active investigations
        </p>
      </div>
      
      {/* Risk factors */}
      <div className="w-full mt-6 space-y-3">
        <div className="flex justify-between items-center">
          <span className="text-sm">Transaction Volume</span>
          <div className="w-24 h-2 bg-gray-200 dark:bg-tertiary-600 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: '85%' }}
              transition={{ duration: 0.8, delay: 1.2 }}
              className="h-full bg-secondary-500"
            ></motion.div>
          </div>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-sm">Entity Connections</span>
          <div className="w-24 h-2 bg-gray-200 dark:bg-tertiary-600 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: '65%' }}
              transition={{ duration: 0.8, delay: 1.4 }}
              className="h-full bg-accent-500"
            ></motion.div>
          </div>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-sm">Compliance History</span>
          <div className="w-24 h-2 bg-gray-200 dark:bg-tertiary-600 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: '40%' }}
              transition={{ duration: 0.8, delay: 1.6 }}
              className="h-full bg-green-500"
            ></motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RiskScoreWidget;