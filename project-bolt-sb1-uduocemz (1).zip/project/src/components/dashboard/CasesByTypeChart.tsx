import React from 'react';
import { Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Link } from 'react-router-dom';
import { ArrowUpRight } from 'lucide-react';

ChartJS.register(ArcElement, Tooltip, Legend);

const CasesByTypeChart: React.FC = () => {
  const data = {
    labels: ['Fraud', 'Money Laundering', 'Embezzlement', 'Corruption', 'Tax Evasion', 'Cybercrime'],
    datasets: [
      {
        data: [35, 25, 15, 12, 8, 5],
        backgroundColor: [
          'rgba(26, 176, 28, 0.8)', // Kenya Green
          'rgba(239, 68, 68, 0.8)', // Kenya Red
          'rgba(34, 34, 34, 0.8)', // Kenya Black
          'rgba(255, 206, 16, 0.8)', // Kenya Gold
          'rgba(96, 165, 250, 0.8)', // Blue
          'rgba(139, 92, 246, 0.8)', // Purple
        ],
        borderColor: [
          'rgba(26, 176, 28, 1)',
          'rgba(239, 68, 68, 1)',
          'rgba(34, 34, 34, 1)',
          'rgba(255, 206, 16, 1)',
          'rgba(96, 165, 250, 1)',
          'rgba(139, 92, 246, 1)',
        ],
        borderWidth: 2,
        hoverOffset: 15,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    cutout: '75%',
    layout: {
      padding: 20
    },
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        padding: 12,
        titleFont: {
          size: 14,
          weight: 'bold' as const,
        },
        bodyFont: {
          size: 13,
        },
        callbacks: {
          label: function(context: any) {
            const label = context.label || '';
            const value = context.raw || 0;
            const total = context.dataset.data.reduce((a: number, b: number) => a + b, 0);
            const percentage = Math.round((value / total) * 100);
            return `${label}: ${value} cases (${percentage}%)`;
          }
        }
      }
    },
  };

  return (
    <div className="relative h-full">
      <div className="absolute top-0 right-0">
        <Link
          to="/cases"
          className="text-sm text-primary-600 dark:text-primary-400 hover:underline flex items-center gap-1"
        >
          View All Cases
          <ArrowUpRight size={14} />
        </Link>
      </div>
      <div className="h-[300px] flex items-center justify-center">
        <Doughnut data={data} options={options} />
      </div>
      <div className="mt-4 grid grid-cols-3 gap-2">
        {data.labels.map((label, index) => (
          <Link
            key={label}
            to={`/crimes/${label.toLowerCase().replace(' ', '-')}`}
            className="p-2 bg-gray-50 dark:bg-tertiary-800 rounded hover:bg-gray-100 dark:hover:bg-tertiary-700 transition-colors"
          >
            <div className="flex items-center gap-1.5">
              <div
                className="w-2 h-2 rounded-full"
                style={{ backgroundColor: data.datasets[0].backgroundColor[index] }}
              ></div>
              <span className="text-sm font-medium truncate">{label}</span>
            </div>
            <div className="mt-1 pl-3.5">
              <span className="text-lg font-bold">{data.datasets[0].data[index]}</span>
              <span className="text-xs text-gray-500 dark:text-gray-400 ml-1">cases</span>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default CasesByTypeChart;