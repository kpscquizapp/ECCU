import React from 'react';
import { format } from 'date-fns';
import { FileText, AlertCircle, Clock, Database, UserCheck, ShieldCheck } from 'lucide-react';

interface Activity {
  id: number;
  type: 'case_created' | 'alert' | 'analysis' | 'evidence' | 'user_action' | 'compliance';
  title: string;
  description: string;
  timestamp: Date;
  user: {
    name: string;
    role: string;
  };
}

const RecentActivityList: React.FC = () => {
  // Mock data for recent activities
  const activities: Activity[] = [
    {
      id: 1,
      type: 'case_created',
      title: 'New case created',
      description: 'Case #4872 - Suspected fraud scheme at Central Bank',
      timestamp: new Date(2025, 5, 2, 14, 32),
      user: {
        name: 'John Kamau',
        role: 'investigator',
      },
    },
    {
      id: 2,
      type: 'alert',
      title: 'Suspicious transaction detected',
      description: 'Multiple high-value transactions identified in Case #4865',
      timestamp: new Date(2025, 5, 2, 13, 15),
      user: {
        name: 'System',
        role: 'automated',
      },
    },
    {
      id: 3,
      type: 'analysis',
      title: 'Analysis completed',
      description: 'AI analysis of financial statements completed for Case #4861',
      timestamp: new Date(2025, 5, 2, 11, 42),
      user: {
        name: 'Sarah Njeri',
        role: 'analyst',
      },
    },
    {
      id: 4,
      type: 'evidence',
      title: 'New evidence added',
      description: 'Bank statements and transaction records added to Case #4859',
      timestamp: new Date(2025, 5, 2, 10, 18),
      user: {
        name: 'John Kamau',
        role: 'investigator',
      },
    },
    {
      id: 5,
      type: 'user_action',
      title: 'Case assigned',
      description: 'Case #4866 assigned to Investigation Team A',
      timestamp: new Date(2025, 5, 2, 9, 30),
      user: {
        name: 'James Muthoni',
        role: 'supervisor',
      },
    },
    {
      id: 6,
      type: 'compliance',
      title: 'Compliance review completed',
      description: 'AML compliance review for Case #4858 completed',
      timestamp: new Date(2025, 5, 1, 16, 45),
      user: {
        name: 'Daniel Omondi',
        role: 'compliance',
      },
    },
  ];

  const getIcon = (type: Activity['type']) => {
    switch (type) {
      case 'case_created':
        return <FileText size={18} className="text-primary-500" />;
      case 'alert':
        return <AlertCircle size={18} className="text-secondary-500" />;
      case 'analysis':
        return <Clock size={18} className="text-accent-500" />;
      case 'evidence':
        return <Database size={18} className="text-purple-500" />;
      case 'user_action':
        return <UserCheck size={18} className="text-blue-500" />;
      case 'compliance':
        return <ShieldCheck size={18} className="text-green-500" />;
      default:
        return <FileText size={18} className="text-gray-500" />;
    }
  };

  return (
    <div className="space-y-4">
      {activities.map((activity) => (
        <div key={activity.id} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-tertiary-800 transition-colors">
          <div className="p-2 rounded-full bg-gray-100 dark:bg-tertiary-600">
            {getIcon(activity.type)}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between">
              <p className="font-medium truncate">{activity.title}</p>
              <span className="text-xs text-gray-500 dark:text-gray-400 whitespace-nowrap ml-2">
                {format(activity.timestamp, 'HH:mm')}
              </span>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-300 truncate">{activity.description}</p>
            <div className="flex items-center mt-1 text-xs text-gray-500 dark:text-gray-400">
              <span>By {activity.user.name}</span>
              <span className="mx-1">•</span>
              <span className="capitalize">{activity.user.role}</span>
            </div>
          </div>
        </div>
      ))}
      <div className="border-t dark:border-tertiary-600 pt-4 mt-4 text-center">
        <button className="text-sm text-primary-600 dark:text-primary-400 hover:underline">
          View all activity
        </button>
      </div>
    </div>
  );
};

export default RecentActivityList;